import { useState, useRef, useEffect } from "react";
import Peer from "peerjs";
import {
  Pokemon,
  PokemonBox,
  BattlePokemon,
  BattleLogEntry,
  Move,
} from "../types";
import {
  getMovesForPokemon,
  calculateDamage,
  TYPE_COLORS as MOVE_TYPE_COLORS,
} from "../data/battleData";
import { TYPE_COLORS, POKEMON_DATA } from "../data/pokemon";

// ============================================================
// CONSTANTS & HELPERS
// ============================================================
const PEER_PREFIX = "pkbx-";
const CODE_CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

function genCode(): string {
  let c = "";
  for (let i = 0; i < 6; i++)
    c += CODE_CHARS[Math.floor(Math.random() * CODE_CHARS.length)];
  return c;
}

function makeBP(p: Pokemon): BattlePokemon {
  return {
    pokemon: p,
    currentHp: p.stats.hp,
    maxHp: p.stats.hp,
    moves: getMovesForPokemon(p.types),
    statModifiers: { attack: 0, defense: 0, spAtk: 0, spDef: 0, speed: 0 },
  };
}

function hpColor(r: number): string {
  return r > 0.5 ? "#4ade80" : r > 0.2 ? "#fbbf24" : "#ef4444";
}

type Phase =
  | "lobby"
  | "waiting"
  | "connecting"
  | "select"
  | "battle"
  | "result";

// ============================================================
// SUB-COMPONENTS
// ============================================================

function HpBar({ current, max }: { current: number; max: number }) {
  const ratio = Math.max(0, current / max);
  return (
    <div className="w-full">
      <div className="flex justify-between items-center mb-1">
        <span className="text-[10px] font-bold text-white/80 uppercase tracking-wider">
          HP
        </span>
        <span className="text-[10px] font-mono text-white/60">
          {Math.max(0, Math.floor(current))}/{max}
        </span>
      </div>
      <div className="w-full h-2.5 bg-black/40 rounded-full overflow-hidden border border-white/10">
        <div
          className="h-full rounded-full transition-all duration-700 ease-out"
          style={{
            width: `${ratio * 100}%`,
            backgroundColor: hpColor(ratio),
            boxShadow: `0 0 8px ${hpColor(ratio)}60`,
          }}
        />
      </div>
    </div>
  );
}

function Fighter({
  bp,
  side,
  isHit,
  isAttacking,
  isFainted,
}: {
  bp: BattlePokemon;
  side: "me" | "opp";
  isHit: boolean;
  isAttacking: boolean;
  isFainted: boolean;
}) {
  const { pokemon } = bp;
  return (
    <div className="flex flex-col items-center">
      <div
        className={`relative w-28 h-28 sm:w-36 sm:h-36 flex items-center justify-center transition-all duration-300
                    ${isHit ? "animate-bounce" : ""}
                    ${isAttacking ? "scale-110" : "scale-100"}
                    ${isFainted ? "opacity-0 scale-75" : "opacity-100"}`}
        style={{
          filter: isHit ? "brightness(3) saturate(0)" : "none",
          transition: "opacity 0.5s, transform 0.5s",
        }}
      >
        <img
          src={pokemon.sprite}
          alt={pokemon.name}
          className={`w-full h-full object-contain drop-shadow-lg
                      ${side === "opp" ? "scale-x-[-1]" : ""}
                      ${isFainted ? "rotate-90" : ""}`}
          style={{ imageRendering: "pixelated" }}
        />
        <div
          className="absolute inset-0 rounded-full opacity-20 blur-xl"
          style={{
            background:
              bp.currentHp / bp.maxHp > 0.5
                ? "radial-gradient(circle, #4ade8040 0%, transparent 70%)"
                : bp.currentHp / bp.maxHp > 0.2
                ? "radial-gradient(circle, #fbbf2440 0%, transparent 70%)"
                : "radial-gradient(circle, #ef444440 0%, transparent 70%)",
          }}
        />
      </div>
      <div className="mt-1 text-center">
        <span className="text-sm font-extrabold text-white capitalize drop-shadow">
          {pokemon.name}
        </span>
        <span className="ml-1 text-[10px] text-white/40 font-mono">Lv50</span>
      </div>
      <div className="flex gap-1 mt-1">
        {pokemon.types.map((t) => {
          const c = TYPE_COLORS[t];
          return (
            <span
              key={t}
              className="px-1.5 py-[1px] rounded text-[9px] font-bold uppercase tracking-wider"
              style={c ? { backgroundColor: c.bg, color: c.text } : undefined}
            >
              {t}
            </span>
          );
        })}
      </div>
      <div className="w-32 sm:w-40 mt-2">
        <HpBar current={bp.currentHp} max={bp.maxHp} />
      </div>
    </div>
  );
}

function MvBtn({
  move,
  onClick,
  disabled,
}: {
  move: Move;
  onClick: () => void;
  disabled: boolean;
}) {
  const bg = MOVE_TYPE_COLORS[move.type] || "#888";
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className="relative group rounded-xl border-2 overflow-hidden transition-all duration-200
                 disabled:opacity-40 disabled:cursor-not-allowed
                 hover:scale-105 hover:shadow-lg active:scale-95"
      style={{
        borderColor: `${bg}80`,
        background: `linear-gradient(135deg, ${bg}20, ${bg}40)`,
      }}
    >
      <div className="px-2 py-1.5 sm:px-3 sm:py-2">
        <div className="flex items-center justify-between gap-1">
          <span className="text-[11px] sm:text-xs font-bold text-white truncate">
            {move.name}
          </span>
          <span
            className="text-[8px] sm:text-[10px] px-1 py-[1px] rounded font-bold uppercase"
            style={{ backgroundColor: bg, color: "#fff" }}
          >
            {move.type}
          </span>
        </div>
        <div className="flex items-center justify-between mt-0.5">
          <span className="text-[9px] text-white/40">
            {move.category === "special" ? "✦ Sp.Atk" : "⚔ Atk"}
          </span>
          <span className="text-[9px] font-mono text-white/50">
            PWR {move.power}
          </span>
        </div>
      </div>
      <div
        className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-gray-900/95 rounded-lg
                      text-[10px] text-white/80 whitespace-nowrap opacity-0 group-hover:opacity-100
                      transition-opacity pointer-events-none border border-white/10 z-50"
      >
        {move.description}
      </div>
    </button>
  );
}

function BLog({ entries }: { entries: BattleLogEntry[] }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (ref.current) ref.current.scrollTop = ref.current.scrollHeight;
  }, [entries]);
  return (
    <div
      ref={ref}
      className="h-28 sm:h-32 overflow-y-auto bg-black/40 rounded-xl border border-white/10 p-2 space-y-1"
    >
      {entries.length === 0 ? (
        <p className="text-[11px] text-white/30 text-center mt-4">
          Battle log...
        </p>
      ) : (
        entries.map((e, i) => (
          <p
            key={i}
            className={`text-[11px] leading-relaxed ${
              e.type === "damage"
                ? "text-white/90"
                : e.type === "effective"
                ? "text-amber-400 font-semibold"
                : e.type === "faint"
                ? "text-red-400 font-bold"
                : e.type === "turn"
                ? "text-blue-400 font-semibold"
                : "text-white/60"
            }`}
          >
            {e.message}
          </p>
        ))
      )}
    </div>
  );
}

// ============================================================
// MAIN COMPONENT
// ============================================================

interface Props {
  boxes: PokemonBox[];
  onBack: () => void;
}

export default function MultiplayerLobby({ boxes: _boxes, onBack }: Props) {
  // --- State ---
  const [phase, setPhase] = useState<Phase>("lobby");
  const [roomCode, setRoomCode] = useState("");
  const [inputCode, setInputCode] = useState("");
  const [isHost, setIsHost] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  // Selection
  const [myBP, setMyBP] = useState<BattlePokemon | null>(null);
  const [oppBP, setOppBP] = useState<BattlePokemon | null>(null);
  const [iSelected, setISelected] = useState(false);
  const [oppSelected, setOppSelected] = useState(false);

  // Battle
  const [isMyTurn, setIsMyTurn] = useState(false);
  const [turnNum, setTurnNum] = useState(1);
  const [log, setLog] = useState<BattleLogEntry[]>([]);
  const [winner, setWinner] = useState<"me" | "opp" | null>(null);
  const [myHit, setMyHit] = useState(false);
  const [oppHit, setOppHit] = useState(false);
  const [myAtk, setMyAtk] = useState(false);
  const [oppAtk, setOppAtk] = useState(false);
  // Refs
  const peerRef = useRef<Peer | null>(null);
  const connRef = useRef<any>(null);
  const handlerRef = useRef<(data: any) => void>(() => {});

  // --- Keep handler up to date ---
  handlerRef.current = (data: any) => {
    switch (data.type) {
      case "pokemon-selected": {
        const bp = makeBP(data.pokemon);
        setOppBP(bp);
        setOppSelected(true);
        break;
      }
      case "attack": {
        doOpponentAttack(data);
        break;
      }
      case "rematch": {
        resetForRematch();
        break;
      }
    }
  };

  // --- Helpers ---
  const send = (data: any) => {
    try {
      connRef.current?.send(data);
    } catch {}
  };

  const cleanup = () => {
    try {
      connRef.current?.close();
    } catch {}
    try {
      peerRef.current?.destroy();
    } catch {}
    connRef.current = null;
    peerRef.current = null;
  };

  const addLog = (message: string, type: BattleLogEntry["type"] = "info") => {
    setLog((p) => [...p, { message, type }]);
  };

  // --- Create Room ---
  const createRoom = () => {
    setError(null);
    const code = genCode();
    setRoomCode(code);
    setIsHost(true);
    setPhase("waiting");

    const peer = new Peer(`${PEER_PREFIX}${code}`);
    peerRef.current = peer;

    peer.on("open", () => {});

    peer.on("connection", (conn) => {
      connRef.current = conn;

      conn.on("open", () => {
        conn.send({ type: "hello" });
        setPhase("select");
      });

      conn.on("data", (data: any) => handlerRef.current(data));

      conn.on("close", () => {
        setError("Opponent disconnected");
        cleanup();
        setPhase("lobby");
      });
    });

    peer.on("error", (err: any) => {
      if (err.type === "unavailable-id") {
        // Collision, try again
        cleanup();
        createRoom();
      } else {
        setError(`Connection error: ${err.type || err.message}`);
        cleanup();
        setPhase("lobby");
      }
    });
  };

  // --- Join Room ---
  const joinRoom = () => {
    const code = inputCode.trim().toUpperCase();
    if (code.length < 4) return;
    setError(null);
    setRoomCode(code);
    setIsHost(false);
    setPhase("connecting");

    const peer = new Peer();
    peerRef.current = peer;

    peer.on("open", () => {
      const conn = peer.connect(`${PEER_PREFIX}${code}`, { reliable: true });
      connRef.current = conn;

      conn.on("open", () => {
        setPhase("select");
      });

      conn.on("data", (data: any) => handlerRef.current(data));

      conn.on("close", () => {
        setError("Host disconnected");
        cleanup();
        setPhase("lobby");
      });

      conn.on("error", () => {
        setError("Connection failed");
        cleanup();
        setPhase("lobby");
      });
    });

    peer.on("error", (err: any) => {
      if (err.type === "peer-unavailable") {
        setError("Room not found. Check the code and try again.");
      } else {
        setError(`Connection error: ${err.type || err.message}`);
      }
      cleanup();
      setPhase("lobby");
    });
  };

  // --- Select Pokemon ---
  const selectPokemon = (poke: Pokemon) => {
    if (iSelected) return;
    const bp = makeBP(poke);
    setMyBP(bp);
    setISelected(true);
    send({ type: "pokemon-selected", pokemon: poke });
  };

  // Auto-start battle when both selected
  useEffect(() => {
    if (myBP && oppBP && phase === "select") {
      const iGoFirst = isHost
        ? myBP.pokemon.stats.speed >= oppBP.pokemon.stats.speed
        : myBP.pokemon.stats.speed > oppBP.pokemon.stats.speed;
      setIsMyTurn(iGoFirst);
      setTurnNum(1);
      setLog([]);
      setWinner(null);
      setMyHit(false);
      setOppHit(false);
      setMyAtk(false);
      setOppAtk(false);
      addLog("--- Turn 1 ---", "turn");
      addLog(
        `You sent out ${myBP.pokemon.name}!`,
        "info"
      );
      addLog(
        `Opponent sent out ${oppBP.pokemon.name}!`,
        "info"
      );
      setPhase("battle");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [myBP, oppBP]);

  // --- My Attack ---
  const doMyAttack = (moveIdx: number) => {
    if (!myBP || !oppBP || !isMyTurn) return;
    const move = myBP.moves[moveIdx];
    if (!move) return;

    const { damage, effectiveness, isStab } = calculateDamage(
      { pokemon: myBP.pokemon, moves: myBP.moves },
      { pokemon: oppBP.pokemon },
      move
    );

    // Send to opponent
    send({
      type: "attack",
      moveIndex: moveIdx,
      moveName: move.name,
      damage,
      effectiveness,
      isStab,
    });

    setIsMyTurn(false);

    // Animate my attack
    setMyAtk(true);
    setTimeout(() => {
      setMyAtk(false);
      setOppHit(true);
      const newHp = Math.max(0, oppBP.currentHp - damage);
      setOppBP((p: BattlePokemon | null) =>
        p ? { ...p, currentHp: newHp } : null
      );

      addLog(`You used ${move.name}!`, "damage");
      if (isStab) addLog("Same-type attack bonus!", "info");
      if (effectiveness >= 2) addLog("It's super effective!", "effective");
      else if (effectiveness > 0 && effectiveness < 1)
        addLog("It's not very effective...", "effective");
      else if (effectiveness === 0) addLog("It had no effect!", "miss");
      addLog(`It dealt ${damage} damage!`, "damage");

      setTimeout(() => {
        setOppHit(false);
        if (newHp <= 0) {
          addLog(`Opponent's ${oppBP.pokemon.name} fainted!`, "faint");
          setWinner("me");
          setPhase("result");
        } else {
          // Now opponent's turn
        }
      }, 500);
    }, 400);
  };

  // --- Opponent Attack ---
  const doOpponentAttack = (data: any) => {
    if (!myBP || !oppBP) return;

    const moveIdx = data.moveIndex;
    const move = oppBP.moves[moveIdx];
    if (!move) return;

    const damage = data.damage;

    // Animate opponent attack
    setOppAtk(true);
    setTimeout(() => {
      setOppAtk(false);
      setMyHit(true);
      const newHp = Math.max(0, myBP.currentHp - damage);
      setMyBP((p: BattlePokemon | null) =>
        p ? { ...p, currentHp: newHp } : null
      );

      addLog(`Opponent used ${data.moveName || move.name}!`, "damage");
      if (data.isStab) addLog("Same-type attack bonus!", "info");
      if (data.effectiveness >= 2)
        addLog("It's super effective!", "effective");
      else if (data.effectiveness > 0 && data.effectiveness < 1)
        addLog("It's not very effective...", "effective");
      else if (data.effectiveness === 0) addLog("It had no effect!", "miss");
      addLog(`You took ${damage} damage!`, "damage");

      setTimeout(() => {
        setMyHit(false);
        if (newHp <= 0) {
          addLog(`Your ${myBP.pokemon.name} fainted!`, "faint");
          setWinner("opp");
          setPhase("result");
        } else {
          // My turn now
          setIsMyTurn(true);
          setTurnNum((t) => {
            const next = t + 1;
            addLog(`--- Turn ${next} ---`, "turn");
            return next;
          });
        }
      }, 500);
    }, 400);
  };

  // --- Rematch ---
  const resetForRematch = () => {
    setMyBP(null);
    setOppBP(null);
    setISelected(false);
    setOppSelected(false);
    setLog([]);
    setWinner(null);
    setMyHit(false);
    setOppHit(false);
    setMyAtk(false);
    setOppAtk(false);
    setPhase("select");
  };

  const handleRematch = () => {
    send({ type: "rematch" });
    resetForRematch();
  };

  // --- Leave ---
  const handleLeave = () => {
    cleanup();
    setPhase("lobby");
    setMyBP(null);
    setOppBP(null);
    setISelected(false);
    setOppSelected(false);
    setLog([]);
    setWinner(null);
    setError(null);
    setInputCode("");
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      cleanup();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // --- Copy code ---
  const copyCode = () => {
    navigator.clipboard.writeText(roomCode).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // All Pokemon for selection
  const allPokemon = POKEMON_DATA;

  // ============================================================
  // RENDER
  // ============================================================

  // ========= LOBBY =========
  if (phase === "lobby") {
    return (
      <div className="max-w-2xl mx-auto space-y-6">
        <div className="text-center">
          <h2 className="text-2xl font-extrabold text-white">
            🌐 Multiplayer Battle
          </h2>
          <p className="text-sm text-white/50 mt-1">
            Battle a friend in real-time with room codes
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Create Room */}
          <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-6 text-center space-y-4 hover:border-emerald-500/30 transition-colors">
            <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br from-emerald-600/20 to-emerald-400/10 flex items-center justify-center border border-emerald-500/20">
              <span className="text-3xl">🏠</span>
            </div>
            <h3 className="text-lg font-bold text-white">Create Room</h3>
            <p className="text-xs text-white/40 leading-relaxed">
              Create a room and share the code with your friend to start
              battling
            </p>
            <button
              onClick={createRoom}
              className="w-full px-4 py-3 bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 rounded-xl text-sm font-bold text-white shadow-lg shadow-emerald-500/20 transition-all hover:scale-105 active:scale-95"
            >
              Create Room
            </button>
          </div>

          {/* Join Room */}
          <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-6 text-center space-y-4 hover:border-blue-500/30 transition-colors">
            <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br from-blue-600/20 to-blue-400/10 flex items-center justify-center border border-blue-500/20">
              <span className="text-3xl">🔗</span>
            </div>
            <h3 className="text-lg font-bold text-white">Join Room</h3>
            <p className="text-xs text-white/40 leading-relaxed">
              Enter a room code shared by your friend to join their battle room
            </p>
            <input
              type="text"
              value={inputCode}
              onChange={(e) =>
                setInputCode(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, ""))
              }
              placeholder="ENTER CODE"
              maxLength={6}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-2.5 text-center text-lg font-mono font-bold tracking-[0.3em] text-white placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-transparent"
              onKeyDown={(e) => e.key === "Enter" && joinRoom()}
            />
            <button
              onClick={joinRoom}
              disabled={inputCode.length < 4}
              className="w-full px-4 py-3 bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 disabled:from-slate-700 disabled:to-slate-700 disabled:text-slate-500 disabled:shadow-none rounded-xl text-sm font-bold text-white shadow-lg shadow-blue-500/20 transition-all hover:scale-105 active:scale-95 disabled:hover:scale-100"
            >
              Join Room
            </button>
          </div>
        </div>

        {/* Error */}
        {error && (
          <div className="bg-red-900/30 border border-red-500/30 rounded-xl p-3 text-center">
            <p className="text-sm text-red-400">⚠️ {error}</p>
            <button
              onClick={() => setError(null)}
              className="text-xs text-red-400/60 hover:text-red-400 mt-1"
            >
              Dismiss
            </button>
          </div>
        )}

        {/* Info box */}
        <div className="bg-slate-800/30 border border-slate-700/50 rounded-xl p-4 text-center">
          <p className="text-xs text-white/30 leading-relaxed">
            <strong className="text-white/50">How it works:</strong> One player
            creates a room and gets a 6-character code. Share that code with
            your friend. They enter the code to join. Both players then pick
            their Pokémon and battle in real-time!
          </p>
        </div>

        <div className="flex justify-center">
          <button
            onClick={onBack}
            className="px-5 py-2.5 rounded-xl bg-slate-800/60 hover:bg-slate-700/60 text-sm font-semibold text-white/60 hover:text-white transition-colors"
          >
            ← Back to Boxes
          </button>
        </div>
      </div>
    );
  }

  // ========= WAITING (Host) =========
  if (phase === "waiting") {
    return (
      <div className="max-w-md mx-auto space-y-6 text-center">
        <div>
          <h2 className="text-xl font-extrabold text-white">
            ⏳ Waiting for Opponent
          </h2>
          <p className="text-xs text-white/40 mt-1">
            Share this room code with your friend
          </p>
        </div>

        {/* Room code display */}
        <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-6 space-y-4">
          <p className="text-[10px] text-white/40 uppercase tracking-widest font-bold">
            Room Code
          </p>
          <div className="flex items-center justify-center gap-2">
            {roomCode.split("").map((ch, i) => (
              <div
                key={i}
                className="w-10 h-12 bg-slate-800 border-2 border-emerald-500/30 rounded-lg flex items-center justify-center text-xl font-mono font-black text-emerald-400"
              >
                {ch}
              </div>
            ))}
          </div>
          <button
            onClick={copyCode}
            className={`px-4 py-2 rounded-lg text-xs font-semibold transition-all ${
              copied
                ? "bg-emerald-600 text-white"
                : "bg-slate-700 hover:bg-slate-600 text-white/70"
            }`}
          >
            {copied ? "✓ Copied!" : "📋 Copy Code"}
          </button>
        </div>

        {/* Animated waiting */}
        <div className="flex items-center justify-center gap-2 py-4">
          <div className="w-3 h-3 rounded-full bg-emerald-400 animate-bounce" style={{ animationDelay: "0ms" }} />
          <div className="w-3 h-3 rounded-full bg-emerald-400 animate-bounce" style={{ animationDelay: "150ms" }} />
          <div className="w-3 h-3 rounded-full bg-emerald-400 animate-bounce" style={{ animationDelay: "300ms" }} />
        </div>
        <p className="text-sm text-white/40">
          Waiting for your friend to join...
        </p>

        <button
          onClick={handleLeave}
          className="px-5 py-2.5 rounded-xl bg-slate-800/60 hover:bg-slate-700/60 text-sm font-semibold text-white/60 hover:text-white transition-colors"
        >
          Cancel
        </button>
      </div>
    );
  }

  // ========= CONNECTING (Guest) =========
  if (phase === "connecting") {
    return (
      <div className="max-w-md mx-auto space-y-6 text-center">
        <div>
          <h2 className="text-xl font-extrabold text-white">
            🔗 Connecting...
          </h2>
          <p className="text-xs text-white/40 mt-1">
            Joining room <span className="font-mono text-blue-400">{roomCode}</span>
          </p>
        </div>

        <div className="flex items-center justify-center gap-2 py-8">
          <div className="w-3 h-3 rounded-full bg-blue-400 animate-bounce" style={{ animationDelay: "0ms" }} />
          <div className="w-3 h-3 rounded-full bg-blue-400 animate-bounce" style={{ animationDelay: "150ms" }} />
          <div className="w-3 h-3 rounded-full bg-blue-400 animate-bounce" style={{ animationDelay: "300ms" }} />
        </div>

        {error && (
          <div className="bg-red-900/30 border border-red-500/30 rounded-xl p-3">
            <p className="text-sm text-red-400">⚠️ {error}</p>
          </div>
        )}

        <button
          onClick={handleLeave}
          className="px-5 py-2.5 rounded-xl bg-slate-800/60 hover:bg-slate-700/60 text-sm font-semibold text-white/60 hover:text-white transition-colors"
        >
          Cancel
        </button>
      </div>
    );
  }

  // ========= POKEMON SELECT =========
  if (phase === "select") {
    return (
      <div className="max-w-3xl mx-auto space-y-4">
        <div className="text-center">
          <h2 className="text-xl font-extrabold text-white">
            Choose Your Pokémon
          </h2>
          <div className="flex items-center justify-center gap-3 mt-2">
            <div className="flex items-center gap-1.5">
              <div
                className={`w-2.5 h-2.5 rounded-full ${
                  iSelected ? "bg-emerald-400" : "bg-slate-600"
                }`}
              />
              <span className="text-[10px] text-white/50">
                {iSelected ? "You are ready" : "Selecting..."}
              </span>
            </div>
            <div className="flex items-center gap-1.5">
              <div
                className={`w-2.5 h-2.5 rounded-full ${
                  oppSelected ? "bg-emerald-400" : "bg-amber-400 animate-pulse"
                }`}
              />
              <span className="text-[10px] text-white/50">
                {oppSelected
                  ? "Opponent is ready"
                  : "Waiting for opponent..."}
              </span>
            </div>
          </div>
        </div>

        {/* Connection status */}
        <div className="flex items-center justify-center gap-2 bg-emerald-900/20 border border-emerald-500/20 rounded-lg px-3 py-1.5 mx-auto w-fit">
          <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-[10px] text-emerald-400/80 font-medium">
            Connected to room {roomCode}
          </span>
        </div>

        {iSelected ? (
          <div className="text-center py-12 space-y-4">
            <div className="w-24 h-24 mx-auto rounded-2xl bg-slate-800/50 border border-white/10 flex items-center justify-center p-2">
              {myBP && (
                <img
                  src={myBP.pokemon.sprite}
                  alt={myBP.pokemon.name}
                  className="w-full h-full object-contain"
                  style={{ imageRendering: "pixelated" }}
                />
              )}
            </div>
            <p className="text-sm text-white/70 font-medium">
              You selected{" "}
              <span className="text-emerald-400 font-bold capitalize">
                {myBP?.pokemon.name}
              </span>
            </p>
            <p className="text-xs text-white/30">
              {oppSelected
                ? "Starting battle..."
                : "Waiting for opponent to select..."}
            </p>
            <div className="flex items-center justify-center gap-2">
              <div className="w-2 h-2 rounded-full bg-amber-400 animate-bounce" style={{ animationDelay: "0ms" }} />
              <div className="w-2 h-2 rounded-full bg-amber-400 animate-bounce" style={{ animationDelay: "150ms" }} />
              <div className="w-2 h-2 rounded-full bg-amber-400 animate-bounce" style={{ animationDelay: "300ms" }} />
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-5 sm:grid-cols-8 md:grid-cols-10 gap-2 max-h-[55vh] overflow-y-auto p-3 bg-black/20 rounded-xl border border-white/10">
            {allPokemon.map((poke) => (
              <button
                key={poke.id}
                onClick={() => selectPokemon(poke)}
                className="group flex flex-col items-center p-1.5 rounded-xl bg-white/5 border border-white/10
                           hover:bg-white/15 hover:border-white/25 hover:scale-110 transition-all duration-200"
              >
                <img
                  src={poke.sprite}
                  alt={poke.name}
                  className="w-12 h-12 object-contain"
                  style={{ imageRendering: "pixelated" }}
                />
                <span className="text-[9px] text-white/70 group-hover:text-white font-medium capitalize truncate w-full text-center mt-0.5">
                  {poke.name}
                </span>
              </button>
            ))}
          </div>
        )}

        <div className="flex justify-center">
          <button
            onClick={handleLeave}
            className="px-4 py-2 rounded-xl bg-slate-800/60 hover:bg-slate-700/60 text-xs font-semibold text-white/50 hover:text-white transition-colors"
          >
            ← Leave Room
          </button>
        </div>
      </div>
    );
  }

  // ========= BATTLE =========
  if (phase === "battle" && myBP && oppBP) {
    return (
      <div
        className="max-w-3xl mx-auto rounded-2xl border border-white/10 overflow-hidden shadow-2xl"
        style={{
          background:
            "linear-gradient(180deg, #1a1a3e 0%, #0d1b2a 40%, #1b2838 100%)",
        }}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-2 bg-black/30 border-b border-white/10">
          <div className="flex items-center gap-2">
            <span className="text-sm">🌐</span>
            <span className="text-xs font-bold text-white/60 uppercase tracking-wider">
              Online Battle
            </span>
            <span className="text-[10px] text-emerald-400/80 font-mono">
              ● Room {roomCode}
            </span>
          </div>
          <span className="text-xs font-mono text-white/40">Turn {turnNum}</span>
          <button
            onClick={handleLeave}
            className="text-xs text-white/40 hover:text-white/80 transition-colors"
          >
            Retreat ↩
          </button>
        </div>

        {/* Battle field */}
        <div className="relative px-4 sm:px-8 pt-6 pb-4">
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <div className="absolute bottom-0 left-0 right-0 h-20 bg-gradient-to-t from-emerald-900/20 to-transparent" />
          </div>

          <div className="relative flex items-center justify-around">
            <div className="transform translate-y-4">
              <div className="text-center mb-1">
                <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider">
                  You
                </span>
              </div>
              <Fighter
                bp={myBP}
                side="me"
                isHit={myHit}
                isAttacking={myAtk}
                isFainted={myBP.currentHp <= 0}
              />
            </div>

            <div className="flex flex-col items-center gap-2 px-2">
              <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-gradient-to-br from-purple-600 to-purple-800 border-4 border-white/20 flex items-center justify-center shadow-lg shadow-purple-500/30">
                <span className="text-xs font-black text-white">VS</span>
              </div>
            </div>

            <div className="transform -translate-y-4">
              <div className="text-center mb-1">
                <span className="text-[10px] font-bold text-red-400 uppercase tracking-wider">
                  Opponent
                </span>
              </div>
              <Fighter
                bp={oppBP}
                side="opp"
                isHit={oppHit}
                isAttacking={oppAtk}
                isFainted={oppBP.currentHp <= 0}
              />
            </div>
          </div>
        </div>

        {/* Moves */}
        <div className="px-4 pb-3 space-y-3">
          <div className="grid grid-cols-2 gap-2">
            {myBP.moves.map((move, i) => (
              <MvBtn
                key={move.name}
                move={move}
                onClick={() => doMyAttack(i)}
                disabled={!isMyTurn}
              />
            ))}
          </div>

          {!isMyTurn && (
            <div className="text-center py-1">
              <span className="text-xs text-white/40 animate-pulse">
                ⏳ Waiting for opponent's move...
              </span>
            </div>
          )}
          {isMyTurn && (
            <div className="text-center py-1">
              <span className="text-xs text-emerald-400 font-semibold">
                ⚔️ Your turn — choose a move!
              </span>
            </div>
          )}

          <BLog entries={log} />
        </div>
      </div>
    );
  }

  // ========= RESULT =========
  if (phase === "result" && myBP && oppBP) {
    const won = winner === "me";
    return (
      <div
        className="max-w-2xl mx-auto rounded-2xl border border-white/10 p-6 shadow-2xl space-y-6"
        style={{
          background: won
            ? "linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)"
            : "linear-gradient(135deg, #1a1a2e 0%, #2d1b30 50%, #4a0e0e 100%)",
        }}
      >
        <div className="text-center">
          <div className="text-5xl mb-3">{won ? "🏆" : "💀"}</div>
          <h2
            className={`text-3xl font-extrabold ${
              won ? "text-amber-400" : "text-red-400"
            }`}
          >
            {won ? "Victory!" : "Defeat!"}
          </h2>
          <p className="text-white/50 text-sm mt-1">
            {won
              ? `Your ${myBP.pokemon.name} defeated opponent's ${oppBP.pokemon.name}!`
              : `Your ${myBP.pokemon.name} was defeated by opponent's ${oppBP.pokemon.name}!`}
          </p>
        </div>

        <div className="flex items-center justify-center gap-8">
          <div className={`flex flex-col items-center ${won ? "" : "opacity-50"}`}>
            <img
              src={myBP.pokemon.sprite}
              alt={myBP.pokemon.name}
              className={`w-20 h-20 object-contain ${won ? "" : "rotate-90 opacity-50"}`}
              style={{ imageRendering: "pixelated" }}
            />
            <span className="text-xs font-bold text-emerald-400 capitalize mt-1">
              You
            </span>
            <span className="text-[10px] text-white/40 capitalize">
              {myBP.pokemon.name}
            </span>
            <span className="text-[10px] text-white/30 font-mono">
              HP: {Math.max(0, Math.floor(myBP.currentHp))}/{myBP.maxHp}
            </span>
          </div>
          <span className="text-2xl font-black text-white/30">VS</span>
          <div className={`flex flex-col items-center ${won ? "opacity-50" : ""}`}>
            <img
              src={oppBP.pokemon.sprite}
              alt={oppBP.pokemon.name}
              className={`w-20 h-20 object-contain ${won ? "rotate-90 opacity-50" : ""}`}
              style={{ imageRendering: "pixelated" }}
            />
            <span className="text-xs font-bold text-red-400 capitalize mt-1">
              Opponent
            </span>
            <span className="text-[10px] text-white/40 capitalize">
              {oppBP.pokemon.name}
            </span>
            <span className="text-[10px] text-white/30 font-mono">
              HP: {Math.max(0, Math.floor(oppBP.currentHp))}/{oppBP.maxHp}
            </span>
          </div>
        </div>

        {/* Battle log summary */}
        <BLog entries={log} />

        <div className="flex gap-3 justify-center">
          <button
            onClick={handleRematch}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-purple-500
                       hover:from-purple-500 hover:to-purple-400 text-sm font-bold text-white
                       shadow-lg shadow-purple-500/20 hover:shadow-purple-500/40 transition-all hover:scale-105"
          >
            ⚔️ Rematch
          </button>
          <button
            onClick={handleLeave}
            className="px-5 py-2.5 rounded-xl bg-slate-700/60 hover:bg-slate-600/60
                       text-sm font-semibold text-white/70 hover:text-white transition-colors"
          >
            🚪 Leave Room
          </button>
        </div>
      </div>
    );
  }

  // Fallback
  return (
    <div className="text-center py-8">
      <p className="text-white/40">Loading...</p>
      <button
        onClick={handleLeave}
        className="mt-4 px-4 py-2 bg-slate-700 rounded-lg text-sm text-white/60"
      >
        Back to Lobby
      </button>
    </div>
  );
}
