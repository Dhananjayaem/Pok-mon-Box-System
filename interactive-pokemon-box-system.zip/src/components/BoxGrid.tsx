import { Pokemon, PokemonBox, DragInfo, ThemeConfig } from "../types";
import { COLS } from "../data/pokemon";
import PokemonSlot from "./PokemonSlot";

interface BoxGridProps {
  box: PokemonBox;
  boxIdx: number;
  themeConfig: ThemeConfig;
  dragSource: DragInfo | null;
  dragOver: DragInfo | null;
  searchType: string | null;
  searchTerm: string;
  onDragStart: (e: React.DragEvent, boxIdx: number, slotIdx: number) => void;
  onDragEnd: () => void;
  onDrop: (e: React.DragEvent, boxIdx: number, slotIdx: number) => void;
  onDragOver: (e: React.DragEvent) => void;
  onDragEnter: (boxIdx: number, slotIdx: number) => void;
  onDragLeave: () => void;
}

export default function BoxGrid({
  box,
  boxIdx,
  themeConfig,
  dragSource,
  dragOver,
  searchType,
  searchTerm,
  onDragStart,
  onDragEnd,
  onDrop,
  onDragOver,
  onDragEnter,
  onDragLeave,
}: BoxGridProps) {
  const isFiltered = searchType !== null || searchTerm.length > 0;

  const checkHighlighted = (pokemon: Pokemon | null): boolean => {
    if (!pokemon) return true;
    if (!isFiltered) return true;

    const matchesType = searchType
      ? pokemon.types.some((t) => t === searchType)
      : true;

    const matchesName = searchTerm
      ? pokemon.name.toLowerCase().includes(searchTerm.toLowerCase())
      : true;

    return matchesType && matchesName;
  };

  const hasVisiblePokemon = box.slots.some(
    (slot) => slot.pokemon && checkHighlighted(slot.pokemon)
  );

  return (
    <div className="relative">
      <div
        className="rounded-2xl p-3 sm:p-5 box-transition pokeball-pattern border border-white/10 shadow-xl"
        style={{ background: themeConfig.gradient }}
      >
        {/* Box label */}
        <div className="flex items-center justify-between mb-3">
          <h2
            className="text-sm font-bold tracking-wide uppercase opacity-60"
            style={{ color: themeConfig.textColor }}
          >
            {themeConfig.emoji} {box.name}
          </h2>
          <span
            className="text-xs font-mono opacity-40"
            style={{ color: themeConfig.textColor }}
          >
            {box.slots.filter((s) => s.pokemon).length}/30
          </span>
        </div>

        {/* Grid */}
        <div
          className="grid gap-1.5 sm:gap-2"
          style={{ gridTemplateColumns: `repeat(${COLS}, minmax(0, 1fr))` }}
        >
          {box.slots.map((slot, slotIdx) => (
            <PokemonSlot
              key={slotIdx}
              pokemon={slot.pokemon}
              boxIdx={boxIdx}
              slotIdx={slotIdx}
              onDragStart={onDragStart}
              onDragEnd={onDragEnd}
              onDrop={onDrop}
              onDragOver={onDragOver}
              onDragEnter={onDragEnter}
              onDragLeave={onDragLeave}
              isDragSource={
                dragSource?.boxIdx === boxIdx &&
                dragSource?.slotIdx === slotIdx
              }
              isDragOver={
                dragOver?.boxIdx === boxIdx && dragOver?.slotIdx === slotIdx
              }
              isHighlighted={checkHighlighted(slot.pokemon)}
              themeConfig={themeConfig}
            />
          ))}
        </div>
      </div>

      {/* No results overlay */}
      {isFiltered && !hasVisiblePokemon && (
        <div className="absolute inset-0 flex items-center justify-center rounded-2xl bg-black/40 backdrop-blur-sm">
          <div className="text-center">
            <span className="text-3xl block mb-2">🔍</span>
            <p className="text-white/80 text-sm font-medium">
              No matching Pokémon
            </p>
            <p className="text-white/40 text-xs mt-1">
              Try a different filter
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
