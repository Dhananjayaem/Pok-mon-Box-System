import { useState, useEffect, useRef, useCallback } from "react";
import {
  Pokemon,
  PokemonBox,
  BattlePokemon,
  BattlePhase,
  BattleLogEntry,
  Move,
} from "../types";
import {
  getMovesForPokemon,
  calculateDamage,
  TYPE_COLORS as BATTLE_TYPE_COLORS,
} from "../data/battleData";
import { TYPE_COLORS, POKEMON_DATA } from "../data/pokemon";

// ============================================================
// HELPERS
// ============================================================

function createBattlePokemon(pokemon: Pokemon): BattlePokemon {
  return {
    pokemon,
    currentHp: pokemon.stats.hp,
    maxHp: pokemon.stats.hp,
    moves: getMovesForPokemon(pokemon.types),
    statModifiers: {
      attack: 0,
      defense: 0,
      spAtk: 0,
      spDef: 0,
      speed: 0,
    },
  };
}

function getHpColor(ratio: number): string {
  if (ratio > 0.5) return "#4ade80";
  if (ratio > 0.2) return "#fbbf24";
  return "#ef4444";
}

function getEffectivenessText(multiplier: number): { text: string; type: BattleLogEntry["type"] } | null {
  if (multiplier >= 2) return { text: "It's super effective!", type: "effective" };
  if (multiplier > 0 && multiplier < 1) return { text: "It's not very effective...", type: "effective" };
  if (multiplier === 0) return { text: "It had no effect!", type: "miss" };
  return null;
}

// ============================================================
// HP BAR COMPONENT
// ============================================================

function HpBar({ current, max, label }: { current: number; max: number; label: string }) {
  const ratio = Math.max(0, current / max);
  const pct = ratio * 100;
  const color = getHpColor(ratio);

  return (
    <div className="w-full">
      <div className="flex justify-between items-center mb-1">
        <span className="text-xs font-bold text-white/80 uppercase tracking-wider">{label}</span>
        <span className="text-xs font-mono text-white/60">
          {Math.max(0, Math.floor(current))}/{max}
        </span>
      </div>
      <div className="w-full h-3 bg-black/40 rounded-full overflow-hidden border border-white/10">
        <div
          className="h-full rounded-full transition-all duration-700 ease-out"
          style={{
            width: `${pct}%`,
            backgroundColor: color,
            boxShadow: `0 0 8px ${color}60`,
          }}
        />
      </div>
    </div>
  );
}

// ============================================================
// POKEMON FIGHTER DISPLAY
// ============================================================

function FighterDisplay({
  battlePokemon,
  side,
  isHit,
  isAttacking,
  isFainted,
}: {
  battlePokemon: BattlePokemon;
  side: "player" | "enemy";
  isHit: boolean;
  isAttacking: boolean;
  isFainted: boolean;
}) {
  const { pokemon } = battlePokemon;
  const hpRatio = battlePokemon.currentHp / battlePokemon.maxHp;

  return (
    <div className={`flex flex-col items-center ${side === "player" ? "" : ""}`}>
      {/* Pokemon sprite */}
      <div
        className={`relative w-32 h-32 sm:w-40 sm:h-40 flex items-center justify-center transition-all duration-300
                    ${isHit ? "animate-bounce" : ""}
                    ${isAttacking ? "scale-110" : "scale-100"}
                    ${isFainted ? "opacity-0 scale-75" : "opacity-100 scale-100"}`}
        style={{
          transition: "opacity 0.5s, transform 0.5s",
          filter: isHit ? "brightness(3) saturate(0)" : "none",
        }}
      >
        <img
          src={pokemon.sprite}
          alt={pokemon.name}
          className={`w-full h-full object-contain drop-shadow-lg
                      ${side === "enemy" ? "scale-x-[-1]" : ""}
                      ${isFainted ? "rotate-90" : ""}`}
          style={{
            imageRendering: "pixelated",
            transition: "transform 0.5s",
          }}
        />
        {/* Glow effect */}
        <div
          className="absolute inset-0 rounded-full opacity-30 blur-xl"
          style={{
            background: hpRatio > 0.5
              ? "radial-gradient(circle, #4ade8040 0%, transparent 70%)"
              : hpRatio > 0.2
              ? "radial-gradient(circle, #fbbf2440 0%, transparent 70%)"
              : "radial-gradient(circle, #ef444440 0%, transparent 70%)",
          }}
        />
      </div>

      {/* Name + Level tag */}
      <div className="mt-1 text-center">
        <span className="text-sm font-extrabold text-white capitalize drop-shadow">
          {pokemon.name}
        </span>
        <span className="ml-1.5 text-[10px] text-white/40 font-mono">Lv50</span>
      </div>

      {/* Type badges */}
      <div className="flex gap-1 mt-1">
        {pokemon.types.map((t) => {
          const colors = TYPE_COLORS[t];
          return (
            <span
              key={t}
              className="px-1.5 py-[1px] rounded text-[9px] font-bold uppercase tracking-wider"
              style={colors ? { backgroundColor: colors.bg, color: colors.text } : undefined}
            >
              {t}
            </span>
          );
        })}
      </div>

      {/* HP Bar */}
      <div className="w-36 sm:w-44 mt-2">
        <HpBar
          current={battlePokemon.currentHp}
          max={battlePokemon.maxHp}
          label="HP"
        />
      </div>
    </div>
  );
}

// ============================================================
// MOVE BUTTON
// ============================================================

function MoveButton({
  move,
  onClick,
  disabled,
}: {
  move: Move;
  onClick: () => void;
  disabled: boolean;
}) {
  const bgColor = BATTLE_TYPE_COLORS[move.type] || "#888";
  const isSpecial = move.category === "special";

  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className="relative group rounded-xl border-2 overflow-hidden transition-all duration-200
                 disabled:opacity-40 disabled:cursor-not-allowed
                 hover:scale-105 hover:shadow-lg active:scale-95"
      style={{
        borderColor: `${bgColor}80`,
        background: `linear-gradient(135deg, ${bgColor}20, ${bgColor}40)`,
      }}
    >
      <div className="px-2 py-1.5 sm:px-3 sm:py-2">
        <div className="flex items-center justify-between gap-1">
          <span className="text-[11px] sm:text-xs font-bold text-white truncate">
            {move.name}
          </span>
          <span
            className="text-[8px] sm:text-[10px] px-1 py-[1px] rounded font-bold uppercase"
            style={{ backgroundColor: bgColor, color: "#fff" }}
          >
            {move.type}
          </span>
        </div>
        <div className="flex items-center justify-between mt-0.5">
          <span className="text-[9px] text-white/40">
            {isSpecial ? "✦ Sp.Atk" : "⚔ Atk"}
          </span>
          <span className="text-[9px] font-mono text-white/50">
            PWR {move.power}
          </span>
        </div>
      </div>
      {/* Tooltip */}
      <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-gray-900/95 rounded-lg
                      text-[10px] text-white/80 whitespace-nowrap opacity-0 group-hover:opacity-100
                      transition-opacity pointer-events-none border border-white/10 z-50">
        {move.description}
      </div>
    </button>
  );
}

// ============================================================
// BATTLE LOG
// ============================================================

function BattleLog({ entries }: { entries: BattleLogEntry[] }) {
  const logRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (logRef.current) {
      logRef.current.scrollTop = logRef.current.scrollHeight;
    }
  }, [entries]);

  return (
    <div
      ref={logRef}
      className="h-32 sm:h-36 overflow-y-auto bg-black/40 rounded-xl border border-white/10 p-2 space-y-1 scrollbar-thin"
    >
      {entries.length === 0 ? (
        <p className="text-[11px] text-white/30 text-center mt-4">Battle log will appear here...</p>
      ) : (
        entries.map((entry, i) => (
          <p
            key={i}
            className={`text-[11px] leading-relaxed ${
              entry.type === "damage"
                ? "text-white/90"
                : entry.type === "effective"
                ? "text-amber-400 font-semibold"
                : entry.type === "miss"
                ? "text-gray-400 italic"
                : entry.type === "faint"
                ? "text-red-400 font-bold"
                : entry.type === "turn"
                ? "text-blue-400 font-semibold"
                : "text-white/60"
            }`}
          >
            {entry.message}
          </p>
        ))
      )}
    </div>
  );
}

// ============================================================
// POKEMON SELECT GRID
// ============================================================

function PokemonSelect({
  boxes,
  onSelect,
  onCancel,
}: {
  boxes: PokemonBox[];
  onSelect: (pokemon: Pokemon) => void;
  onCancel: () => void;
}) {
  const allPokemon = boxes.flatMap((box) =>
    box.slots.filter((s) => s.pokemon).map((s) => s.pokemon!)
  );
  // Deduplicate by id
  const uniquePokemon = Array.from(
    new Map(allPokemon.map((p) => [p.id, p])).values()
  );

  return (
    <div className="space-y-4">
      <div className="text-center">
        <h2 className="text-2xl font-extrabold text-white mb-1">
          ⚔️ Choose Your Fighter
        </h2>
        <p className="text-sm text-white/50">
          Select a Pokémon to send into battle
        </p>
      </div>

      <div className="grid grid-cols-5 sm:grid-cols-8 md:grid-cols-10 gap-2 max-h-[50vh] overflow-y-auto p-2 bg-black/20 rounded-xl border border-white/10">
        {uniquePokemon.map((pokemon) => (
          <button
            key={pokemon.id}
            onClick={() => onSelect(pokemon)}
            className="group flex flex-col items-center p-1.5 rounded-xl bg-white/5 border border-white/10
                       hover:bg-white/15 hover:border-white/25 hover:scale-110 transition-all duration-200"
          >
            <img
              src={pokemon.sprite}
              alt={pokemon.name}
              className="w-12 h-12 object-contain"
              style={{ imageRendering: "pixelated" }}
            />
            <span className="text-[9px] text-white/70 group-hover:text-white font-medium capitalize truncate w-full text-center mt-0.5">
              {pokemon.name}
            </span>
          </button>
        ))}
      </div>

      <div className="flex justify-center">
        <button
          onClick={onCancel}
          className="px-5 py-2 rounded-xl bg-slate-700/60 hover:bg-slate-600/60 text-sm font-semibold text-white/70 hover:text-white transition-colors"
        >
          ← Back to Boxes
        </button>
      </div>
    </div>
  );
}

// ============================================================
// RESULT SCREEN
// ============================================================

function BattleResult({
  won,
  playerPokemon,
  enemyPokemon,
  onRematch,
  onBack,
}: {
  won: boolean;
  playerPokemon: BattlePokemon;
  enemyPokemon: BattlePokemon;
  onRematch: () => void;
  onBack: () => void;
}) {
  return (
    <div className="flex flex-col items-center justify-center py-8 space-y-6">
      {/* Winner display */}
      <div className="text-center">
        <div className="text-5xl mb-3">{won ? "🏆" : "💀"}</div>
        <h2
          className={`text-3xl font-extrabold ${
            won ? "text-amber-400" : "text-red-400"
          }`}
        >
          {won ? "Victory!" : "Defeat!"}
        </h2>
        <p className="text-white/50 text-sm mt-1">
          {won
            ? `${playerPokemon.pokemon.name} defeated ${enemyPokemon.pokemon.name}!`
            : `${playerPokemon.pokemon.name} was defeated by ${enemyPokemon.pokemon.name}!`}
        </p>
      </div>

      {/* Winner / Loser sprites */}
      <div className="flex items-center gap-8">
        <div className={`flex flex-col items-center ${won ? "" : "opacity-50"}`}>
          <img
            src={playerPokemon.pokemon.sprite}
            alt={playerPokemon.pokemon.name}
            className={`w-24 h-24 object-contain ${won ? "" : "rotate-90 opacity-50"}`}
            style={{ imageRendering: "pixelated" }}
          />
          <span className="text-xs font-bold text-white capitalize mt-1">
            {playerPokemon.pokemon.name}
          </span>
          <span className="text-[10px] text-white/40 font-mono">
            HP: {Math.max(0, Math.floor(playerPokemon.currentHp))}/{playerPokemon.maxHp}
          </span>
        </div>
        <span className="text-2xl font-black text-white/30">VS</span>
        <div className={`flex flex-col items-center ${won ? "opacity-50" : ""}`}>
          <img
            src={enemyPokemon.pokemon.sprite}
            alt={enemyPokemon.pokemon.name}
            className={`w-24 h-24 object-contain ${won ? "rotate-90 opacity-50" : ""}`}
            style={{ imageRendering: "pixelated" }}
          />
          <span className="text-xs font-bold text-white capitalize mt-1">
            {enemyPokemon.pokemon.name}
          </span>
          <span className="text-[10px] text-white/40 font-mono">
            HP: {Math.max(0, Math.floor(enemyPokemon.currentHp))}/{enemyPokemon.maxHp}
          </span>
        </div>
      </div>

      {/* Action buttons */}
      <div className="flex gap-3">
        <button
          onClick={onRematch}
          className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-600 to-amber-500
                     hover:from-amber-500 hover:to-amber-400 text-sm font-bold text-white
                     shadow-lg shadow-amber-500/20 hover:shadow-amber-500/40 transition-all hover:scale-105"
        >
          ⚔️ Battle Again
        </button>
        <button
          onClick={onBack}
          className="px-5 py-2.5 rounded-xl bg-slate-700/60 hover:bg-slate-600/60
                     text-sm font-semibold text-white/70 hover:text-white transition-colors"
        >
          ← Back to Boxes
        </button>
      </div>
    </div>
  );
}

// ============================================================
// MAIN BATTLE ARENA
// ============================================================

interface BattleArenaProps {
  boxes: PokemonBox[];
  onBack: () => void;
}

export default function BattleArena({ boxes, onBack }: BattleArenaProps) {
  // Battle state
  const [phase, setPhase] = useState<BattlePhase>("select");
  const [playerPokemon, setPlayerPokemon] = useState<BattlePokemon | null>(null);
  const [enemyPokemon, setEnemyPokemon] = useState<BattlePokemon | null>(null);
  const [log, setLog] = useState<BattleLogEntry[]>([]);
  const [turnCount, setTurnCount] = useState(1);
  const [winner, setWinner] = useState<"player" | "enemy" | null>(null);

  // Animation state
  const [playerHit, setPlayerHit] = useState(false);
  const [enemyHit, setEnemyHit] = useState(false);
  const [playerAttacking, setPlayerAttacking] = useState(false);
  const [enemyAttacking, setEnemyAttacking] = useState(false);

  const addLog = useCallback((message: string, type: BattleLogEntry["type"] = "info") => {
    setLog((prev) => [...prev, { message, type }]);
  }, []);

  // ---- SELECT POKEMON ----
  const handleSelectPokemon = useCallback(
    (pokemon: Pokemon) => {
      const player = createBattlePokemon(pokemon);

      // Pick a random enemy (different from player)
      const candidates = POKEMON_DATA.filter((p) => p.id !== pokemon.id);
      const enemyPoke = candidates[Math.floor(Math.random() * candidates.length)];
      const enemy = createBattlePokemon(enemyPoke);

      setPlayerPokemon(player);
      setEnemyPokemon(enemy);
      setLog([]);
      setTurnCount(1);
      setWinner(null);
      setPhase("intro");

      // Intro messages
      setTimeout(() => {
        addLog(`A wild ${enemyPoke.name} appeared!`, "info");
      }, 300);
      setTimeout(() => {
        addLog(`Go, ${pokemon.name}!`, "info");
      }, 800);
      setTimeout(() => {
        addLog(`--- Turn ${1} ---`, "turn");
        setPhase("playerTurn");
      }, 1400);
    },
    [addLog]
  );

  // ---- EXECUTE MOVE ----
  const executeMove = useCallback(
    (
      attacker: BattlePokemon,
      defender: BattlePokemon,
      move: Move,
      isPlayerAttack: boolean
    ): { newDefenderHp: number; damage: number; effectiveness: number; isStab: boolean } => {
      const { damage, effectiveness, isStab } = calculateDamage(
        { pokemon: attacker.pokemon, moves: attacker.moves },
        { pokemon: defender.pokemon },
        move
      );

      const newHp = Math.max(0, defender.currentHp - damage);

      // Log messages
      const attackerName = attacker.pokemon.name;
      const defenderName = defender.pokemon.name;
      addLog(
        `${isPlayerAttack ? "" : "Enemy "}${attackerName} used ${move.name}!`,
        "damage"
      );

      if (isStab) {
        // Don't explicitly log STAB, it's implied
      }

      const eff = getEffectivenessText(effectiveness);
      if (eff) {
        setTimeout(() => addLog(eff.text, eff.type), 200);
      }

      addLog(`It dealt ${damage} damage!`, "damage");

      if (newHp <= 0) {
        setTimeout(() => {
          addLog(
            `${isPlayerAttack ? "Enemy " : ""}${defenderName} fainted!`,
            "faint"
          );
        }, 400);
      }

      return { newDefenderHp: newHp, damage, effectiveness, isStab };
    },
    [addLog]
  );

  // ---- PLAYER ATTACK ----
  const handlePlayerAttack = useCallback(
    (move: Move) => {
      if (!playerPokemon || !enemyPokemon || phase !== "playerTurn") return;

      setPhase("attacking");
      setPlayerAttacking(true);

      setTimeout(() => {
        setPlayerAttacking(false);

        const result = executeMove(playerPokemon, enemyPokemon, move, true);

        // Show hit animation on enemy
        setEnemyHit(true);
        setEnemyPokemon((prev) =>
          prev ? { ...prev, currentHp: result.newDefenderHp } : null
        );

        setTimeout(() => {
          setEnemyHit(false);

          if (result.newDefenderHp <= 0) {
            // Enemy fainted
            setWinner("player");
            setPhase("result");
          } else {
            // Enemy's turn
            setPhase("enemyTurn");
            setTimeout(() => {
              handleEnemyTurn();
            }, 600);
          }
        }, 500);
      }, 400);
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [playerPokemon, enemyPokemon, phase, executeMove]
  );

  // ---- ENEMY TURN ----
  const handleEnemyTurn = useCallback(() => {
    if (!playerPokemon || !enemyPokemon) return;

    // AI: Pick a random move (with slight preference for effective moves)
    const moves = enemyPokemon.moves;
    const move = moves[Math.floor(Math.random() * moves.length)];

    setPhase("enemyAttacking");
    setEnemyAttacking(true);

    setTimeout(() => {
      setEnemyAttacking(false);

      const result = executeMove(enemyPokemon, playerPokemon, move, false);

      // Show hit animation on player
      setPlayerHit(true);
      setPlayerPokemon((prev) =>
        prev ? { ...prev, currentHp: result.newDefenderHp } : null
      );

      setTimeout(() => {
        setPlayerHit(false);

        if (result.newDefenderHp <= 0) {
          // Player fainted
          setWinner("enemy");
          setPhase("result");
        } else {
          // Next turn
          setTurnCount((prev) => {
            const next = prev + 1;
            addLog(`--- Turn ${next} ---`, "turn");
            return next;
          });
          setPhase("playerTurn");
        }
      }, 500);
    }, 400);
  }, [playerPokemon, enemyPokemon, executeMove, addLog]);

  // ---- REMATCH ----
  const handleRematch = useCallback(() => {
    if (playerPokemon) {
      handleSelectPokemon(playerPokemon.pokemon);
    }
  }, [playerPokemon, handleSelectPokemon]);

  // ---- RENDER ----

  // Selection screen
  if (phase === "select") {
    return (
      <div className="max-w-3xl mx-auto">
        <div className="mb-4">
          <button
            onClick={onBack}
            className="text-sm text-white/50 hover:text-white transition-colors"
          >
            ← Back to Boxes
          </button>
        </div>
        <PokemonSelect boxes={boxes} onSelect={handleSelectPokemon} onCancel={onBack} />
      </div>
    );
  }

  if (!playerPokemon || !enemyPokemon) return null;

  // Result screen
  if (phase === "result") {
    return (
      <div
        className="max-w-2xl mx-auto rounded-2xl border border-white/10 p-6 shadow-2xl"
        style={{
          background: winner === "player"
            ? "linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)"
            : "linear-gradient(135deg, #1a1a2e 0%, #2d1b30 50%, #4a0e0e 100%)",
        }}
      >
        <BattleResult
          won={winner === "player"}
          playerPokemon={playerPokemon}
          enemyPokemon={enemyPokemon}
          onRematch={handleRematch}
          onBack={onBack}
        />
      </div>
    );
  }

  // Battle screen
  const isPlayerTurn = phase === "playerTurn";

  return (
    <div
      className="max-w-3xl mx-auto rounded-2xl border border-white/10 overflow-hidden shadow-2xl"
      style={{
        background: "linear-gradient(180deg, #1a1a3e 0%, #0d1b2a 40%, #1b2838 100%)",
      }}
    >
      {/* Arena header */}
      <div className="flex items-center justify-between px-4 py-2 bg-black/30 border-b border-white/10">
        <div className="flex items-center gap-2">
          <span className="text-sm">⚔️</span>
          <span className="text-xs font-bold text-white/60 uppercase tracking-wider">
            Battle Arena
          </span>
        </div>
        <span className="text-xs font-mono text-white/40">Turn {turnCount}</span>
        <button
          onClick={onBack}
          className="text-xs text-white/40 hover:text-white/80 transition-colors"
        >
          Retreat ↩
        </button>
      </div>

      {/* Battle field */}
      <div className="relative px-4 sm:px-8 pt-6 pb-4">
        {/* Background decorations */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute bottom-0 left-0 right-0 h-20 bg-gradient-to-t from-emerald-900/20 to-transparent" />
          <div className="absolute top-10 left-1/4 w-40 h-40 bg-blue-500/5 rounded-full blur-3xl" />
          <div className="absolute top-20 right-1/4 w-40 h-40 bg-purple-500/5 rounded-full blur-3xl" />
        </div>

        {/* Fighters */}
        <div className="relative flex items-center justify-between sm:justify-around">
          {/* Player Pokemon */}
          <div className="transform translate-y-4">
            <FighterDisplay
              battlePokemon={playerPokemon}
              side="player"
              isHit={playerHit}
              isAttacking={playerAttacking}
              isFainted={playerPokemon.currentHp <= 0}
            />
          </div>

          {/* VS Badge */}
          <div className="flex flex-col items-center gap-2 px-2">
            <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-gradient-to-br from-red-600 to-red-800 border-4 border-white/20 flex items-center justify-center shadow-lg shadow-red-500/30">
              <span className="text-xs sm:text-sm font-black text-white">VS</span>
            </div>
          </div>

          {/* Enemy Pokemon */}
          <div className="transform -translate-y-4">
            <FighterDisplay
              battlePokemon={enemyPokemon}
              side="enemy"
              isHit={enemyHit}
              isAttacking={enemyAttacking}
              isFainted={enemyPokemon.currentHp <= 0}
            />
          </div>
        </div>
      </div>

      {/* Action area */}
      <div className="px-4 pb-4 space-y-3">
        {/* Move buttons */}
        <div className="grid grid-cols-2 gap-2">
          {playerPokemon.moves.map((move) => (
            <MoveButton
              key={move.name}
              move={move}
              onClick={() => handlePlayerAttack(move)}
              disabled={!isPlayerTurn}
            />
          ))}
        </div>

        {/* Waiting indicator */}
        {!isPlayerTurn && (
          <div className="text-center py-1">
            <span className="text-xs text-white/40 animate-pulse">
              {phase === "intro"
                ? "Preparing for battle..."
                : "Enemy is attacking..."}
            </span>
          </div>
        )}

        {/* Battle log */}
        <BattleLog entries={log} />
      </div>
    </div>
  );
}
