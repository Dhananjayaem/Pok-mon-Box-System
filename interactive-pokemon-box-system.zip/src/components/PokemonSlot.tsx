import { useState } from "react";
import { Pokemon, ThemeConfig } from "../types";
import { TYPE_COLORS } from "../data/pokemon";

interface PokemonSlotProps {
  pokemon: Pokemon | null;
  boxIdx: number;
  slotIdx: number;
  onDragStart: (e: React.DragEvent, boxIdx: number, slotIdx: number) => void;
  onDragEnd: () => void;
  onDrop: (e: React.DragEvent, boxIdx: number, slotIdx: number) => void;
  onDragOver: (e: React.DragEvent) => void;
  onDragEnter: (boxIdx: number, slotIdx: number) => void;
  onDragLeave: () => void;
  isDragSource: boolean;
  isDragOver: boolean;
  isHighlighted: boolean;
  themeConfig: ThemeConfig;
}

const STAT_COLORS: Record<string, string> = {
  HP: "#FF5555",
  ATK: "#F08030",
  DEF: "#F8D030",
  SPA: "#6890F0",
  SPD: "#78C850",
  SPE: "#F85888",
};

const STAT_MAX = 255;

function StatBar({
  label,
  value,
  color,
}: {
  label: string;
  value: number;
  color: string;
}) {
  const pct = Math.min((value / STAT_MAX) * 100, 100);
  return (
    <div className="flex items-center gap-1.5">
      <span
        className="w-7 text-[10px] font-bold text-right tabular-nums"
        style={{ color }}
      >
        {label}
      </span>
      <div className="flex-1 h-[6px] bg-gray-700/80 rounded-full overflow-hidden">
        <div
          className="h-full rounded-full transition-all duration-300"
          style={{ width: `${pct}%`, backgroundColor: color }}
        />
      </div>
      <span className="w-7 text-[10px] text-gray-300 text-right tabular-nums">
        {value}
      </span>
    </div>
  );
}

function StatTooltip({
  pokemon,
  isTopRow,
}: {
  pokemon: Pokemon;
  isTopRow: boolean;
}) {
  const bst =
    pokemon.stats.hp +
    pokemon.stats.attack +
    pokemon.stats.defense +
    pokemon.stats.spAtk +
    pokemon.stats.spDef +
    pokemon.stats.speed;

  return (
    <div
      className={`absolute z-50 left-1/2 -translate-x-1/2 pointer-events-none
                    w-52 rounded-xl shadow-2xl border border-white/15
                    bg-gray-900/[0.97] backdrop-blur-sm p-2.5
                    ${isTopRow ? "top-full mt-3 tooltip-below" : "bottom-full mb-3 tooltip-above"}`}
    >
      {/* Arrow */}
      <div
        className={`absolute left-1/2 -translate-x-1/2 w-0 h-0
                       border-l-[7px] border-l-transparent
                       border-r-[7px] border-r-transparent
                       ${
                         isTopRow
                           ? "-top-[6px] border-b-[7px] border-b-gray-900/[0.97]"
                           : "-bottom-[6px] border-t-[7px] border-t-gray-900/[0.97]"
                       }`}
      />

      {/* Header */}
      <div className="flex items-center gap-2 mb-2 pb-2 border-b border-white/10">
        <div className="w-14 h-14 rounded-lg bg-gray-800/80 flex items-center justify-center overflow-hidden shrink-0">
          <img
            src={pokemon.sprite}
            alt={pokemon.name}
            className="w-12 h-12"
            style={{ imageRendering: "pixelated" }}
          />
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="font-bold text-white text-sm capitalize leading-tight truncate">
            {pokemon.name}
          </h3>
          <span className="text-[10px] text-gray-500 font-mono">
            #{String(pokemon.id).padStart(3, "0")}
          </span>
          <div className="flex flex-wrap gap-1 mt-1">
            {pokemon.types.map((type) => {
              const colors = TYPE_COLORS[type];
              return (
                <span
                  key={type}
                  className="px-1.5 py-[1px] rounded-[3px] text-[9px] font-extrabold uppercase tracking-wider"
                  style={
                    colors
                      ? { backgroundColor: colors.bg, color: colors.text }
                      : undefined
                  }
                >
                  {type}
                </span>
              );
            })}
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="space-y-[5px]">
        <StatBar label="HP" value={pokemon.stats.hp} color={STAT_COLORS.HP} />
        <StatBar
          label="ATK"
          value={pokemon.stats.attack}
          color={STAT_COLORS.ATK}
        />
        <StatBar
          label="DEF"
          value={pokemon.stats.defense}
          color={STAT_COLORS.DEF}
        />
        <StatBar
          label="SPA"
          value={pokemon.stats.spAtk}
          color={STAT_COLORS.SPA}
        />
        <StatBar
          label="SPD"
          value={pokemon.stats.spDef}
          color={STAT_COLORS.SPD}
        />
        <StatBar
          label="SPE"
          value={pokemon.stats.speed}
          color={STAT_COLORS.SPE}
        />
      </div>

      {/* BST */}
      <div className="mt-2 pt-1.5 border-t border-white/10 flex justify-between items-center">
        <span className="text-[10px] text-gray-500 font-semibold uppercase tracking-wider">
          Total
        </span>
        <span className="text-xs font-extrabold text-white">{bst}</span>
      </div>
    </div>
  );
}

export default function PokemonSlot({
  pokemon,
  boxIdx,
  slotIdx,
  onDragStart,
  onDragEnd,
  onDrop,
  onDragOver,
  onDragEnter,
  onDragLeave,
  isDragSource,
  isDragOver,
  isHighlighted,
  themeConfig,
}: PokemonSlotProps) {
  const [showTooltip, setShowTooltip] = useState(false);
  const isTopRow = slotIdx < 10;

  return (
    <div
      className={`relative aspect-square rounded-lg border-2 transition-all duration-150 box-transition select-none
                  ${pokemon ? "cursor-grab active:cursor-grabbing slot-pokemon" : "cursor-default"}
                  ${isDragSource ? "dragging-slot" : ""}
                  ${isDragOver ? "drag-over-slot" : ""}
                  ${!isHighlighted && pokemon ? "opacity-25 saturate-0" : ""}`}
      style={{
        backgroundColor: isDragOver
          ? "rgba(250,204,21,0.15)"
          : themeConfig.slotBg,
        borderColor: isDragOver ? "#facc15" : themeConfig.slotBorder,
      }}
      draggable={!!pokemon}
      onDragStart={(e) => {
        if (pokemon) {
          onDragStart(e, boxIdx, slotIdx);
          const img = e.currentTarget.querySelector("img");
          if (img) {
            e.dataTransfer.setDragImage(img, 32, 32);
          }
        }
      }}
      onDragEnd={onDragEnd}
      onDragOver={(e) => {
        e.preventDefault();
        e.dataTransfer.dropEffect = "move";
        onDragOver(e);
      }}
      onDragEnter={() => onDragEnter(boxIdx, slotIdx)}
      onDragLeave={onDragLeave}
      onDrop={(e) => {
        e.preventDefault();
        e.stopPropagation();
        onDrop(e, boxIdx, slotIdx);
      }}
      onMouseEnter={() => pokemon && setShowTooltip(true)}
      onMouseLeave={() => setShowTooltip(false)}
    >
      {pokemon ? (
        <>
          <img
            src={pokemon.sprite}
            alt={pokemon.name}
            className="w-full h-full object-contain p-1 drop-shadow-sm"
            style={{ imageRendering: "pixelated" }}
            draggable={false}
          />
          {showTooltip && !isDragSource && (
            <StatTooltip pokemon={pokemon} isTopRow={isTopRow} />
          )}
        </>
      ) : (
        <div className="w-full h-full flex items-center justify-center">
          <div
            className="w-5 h-5 rounded-full transition-opacity duration-200"
            style={{
              backgroundColor: themeConfig.accent,
              opacity: isDragOver ? 0.3 : 0.06,
            }}
          />
        </div>
      )}
    </div>
  );
}
