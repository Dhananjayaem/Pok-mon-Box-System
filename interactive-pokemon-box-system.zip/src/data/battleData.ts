import { Move, Pokemon } from "../types";

// ============================================================
// TYPE EFFECTIVENESS CHART
// ============================================================
// attackingType -> defendingType -> multiplier
export const TYPE_CHART: Record<string, Record<string, number>> = {
  Normal:   { Rock: 0.5, Ghost: 0, Steel: 0.5 },
  Fire:     { Fire: 0.5, Water: 0.5, Grass: 2, Ice: 2, Bug: 2, Rock: 0.5, Dragon: 0.5, Steel: 2 },
  Water:    { Fire: 2, Water: 0.5, Grass: 0.5, Ground: 2, Rock: 2, Dragon: 0.5 },
  Electric: { Water: 2, Electric: 0.5, Grass: 0.5, Ground: 0, Flying: 2, Dragon: 0.5 },
  Grass:    { Fire: 0.5, Water: 2, Grass: 0.5, Poison: 0.5, Ground: 2, Flying: 0.5, Bug: 0.5, Rock: 2, Dragon: 0.5, Steel: 0.5 },
  Ice:      { Fire: 0.5, Water: 0.5, Grass: 2, Ice: 0.5, Ground: 2, Flying: 2, Dragon: 2, Steel: 0.5 },
  Fighting: { Normal: 2, Ice: 2, Poison: 0.5, Flying: 0.5, Psychic: 0.5, Bug: 0.5, Rock: 2, Ghost: 0, Dark: 2, Steel: 2, Fairy: 0.5 },
  Poison:   { Grass: 2, Poison: 0.5, Ground: 0.5, Rock: 0.5, Ghost: 0.5, Steel: 0, Fairy: 2 },
  Ground:   { Fire: 2, Electric: 2, Grass: 0.5, Poison: 2, Flying: 0, Bug: 0.5, Rock: 2, Steel: 2 },
  Flying:   { Electric: 0.5, Grass: 2, Fighting: 2, Bug: 2, Rock: 0.5, Steel: 0.5 },
  Psychic:  { Fighting: 2, Poison: 2, Psychic: 0.5, Dark: 0, Steel: 0.5 },
  Bug:      { Fire: 0.5, Grass: 2, Fighting: 0.5, Poison: 0.5, Flying: 0.5, Psychic: 2, Ghost: 0.5, Dark: 2, Steel: 0.5, Fairy: 0.5 },
  Rock:     { Fire: 2, Ice: 2, Fighting: 0.5, Ground: 0.5, Flying: 2, Bug: 2, Steel: 0.5 },
  Ghost:    { Normal: 0, Psychic: 2, Ghost: 2, Dark: 0.5 },
  Dragon:   { Dragon: 2, Steel: 0.5, Fairy: 0 },
  Dark:     { Fighting: 0.5, Psychic: 2, Ghost: 2, Dark: 0.5, Fairy: 0.5 },
  Steel:    { Fire: 0.5, Water: 0.5, Electric: 0.5, Ice: 2, Rock: 2, Steel: 0.5, Fairy: 2 },
  Fairy:    { Fire: 0.5, Poison: 0.5, Fighting: 2, Dragon: 2, Dark: 2, Steel: 0.5 },
};

export function getTypeMultiplier(moveType: string, defenderTypes: string[]): number {
  let multiplier = 1;
  for (const defType of defenderTypes) {
    const chart = TYPE_CHART[moveType];
    if (chart && chart[defType] !== undefined) {
      multiplier *= chart[defType];
    }
  }
  return multiplier;
}

// ============================================================
// MOVE DEFINITIONS
// ============================================================

interface MoveTemplate {
  name: string;
  type: string;
  power: number;
  category: "physical" | "special";
  description: string;
}

const MOVE_POOL: MoveTemplate[] = [
  // Normal
  { name: "Tackle", type: "Normal", power: 40, category: "physical", description: "A full-body charge attack." },
  { name: "Body Slam", type: "Normal", power: 85, category: "physical", description: "A full-body slam with heavy impact." },
  { name: "Hyper Beam", type: "Normal", power: 150, category: "special", description: "A devastating energy beam." },
  { name: "Slash", type: "Normal", power: 70, category: "physical", description: "A sharp slash with claws." },

  // Fire
  { name: "Ember", type: "Fire", power: 40, category: "special", description: "A small flame attack." },
  { name: "Fire Punch", type: "Fire", power: 75, category: "physical", description: "A fiery punch." },
  { name: "Flamethrower", type: "Fire", power: 90, category: "special", description: "A stream of intense fire." },
  { name: "Fire Blast", type: "Fire", power: 110, category: "special", description: "An intense fire blast." },

  // Water
  { name: "Water Gun", type: "Water", power: 40, category: "special", description: "A jet of water." },
  { name: "Aqua Tail", type: "Water", power: 85, category: "physical", description: "A water-covered tail whip." },
  { name: "Surf", type: "Water", power: 90, category: "special", description: "A massive tidal wave." },
  { name: "Hydro Pump", type: "Water", power: 110, category: "special", description: "A powerful water blast." },

  // Grass
  { name: "Vine Whip", type: "Grass", power: 45, category: "physical", description: "Strikes with slender vines." },
  { name: "Leaf Blade", type: "Grass", power: 90, category: "physical", description: "A sharp leaf slash." },
  { name: "Energy Ball", type: "Grass", power: 90, category: "special", description: "A ball of nature energy." },
  { name: "Solar Beam", type: "Grass", power: 120, category: "special", description: "A powerful solar beam." },

  // Electric
  { name: "Thunder Shock", type: "Electric", power: 40, category: "special", description: "A jolt of electricity." },
  { name: "Thunder Punch", type: "Electric", power: 75, category: "physical", description: "An electrified punch." },
  { name: "Thunderbolt", type: "Electric", power: 90, category: "special", description: "A strong electric bolt." },
  { name: "Thunder", type: "Electric", power: 110, category: "special", description: "A lightning strike." },

  // Ice
  { name: "Ice Shard", type: "Ice", power: 40, category: "physical", description: "Sharp ice shards." },
  { name: "Icy Wind", type: "Ice", power: 55, category: "special", description: "A biting icy wind." },
  { name: "Ice Beam", type: "Ice", power: 90, category: "special", description: "A freezing ice beam." },
  { name: "Blizzard", type: "Ice", power: 110, category: "special", description: "A howling blizzard." },

  // Fighting
  { name: "Karate Chop", type: "Fighting", power: 50, category: "physical", description: "A sharp karate chop." },
  { name: "Brick Break", type: "Fighting", power: 75, category: "physical", description: "A powerful fighting punch." },
  { name: "Close Combat", type: "Fighting", power: 120, category: "physical", description: "An all-out close attack." },
  { name: "Focus Blast", type: "Fighting", power: 120, category: "special", description: "A focused energy blast." },

  // Poison
  { name: "Poison Sting", type: "Poison", power: 15, category: "physical", description: "A toxic barb attack." },
  { name: "Poison Jab", type: "Poison", power: 80, category: "physical", description: "A poisonous stab." },
  { name: "Sludge Bomb", type: "Poison", power: 90, category: "special", description: "A toxic sludge bomb." },
  { name: "Gunk Shot", type: "Poison", power: 120, category: "physical", description: "A filthy sludge attack." },

  // Ground
  { name: "Mud Shot", type: "Ground", power: 55, category: "special", description: "A muddy projectile." },
  { name: "Dig", type: "Ground", power: 80, category: "physical", description: "An attack from underground." },
  { name: "Earth Power", type: "Ground", power: 90, category: "special", description: "A powerful ground eruption." },
  { name: "Earthquake", type: "Ground", power: 100, category: "physical", description: "A devastating earthquake." },

  // Flying
  { name: "Gust", type: "Flying", power: 40, category: "special", description: "A strong wind gust." },
  { name: "Wing Attack", type: "Flying", power: 60, category: "physical", description: "A sweeping wing attack." },
  { name: "Air Slash", type: "Flying", power: 75, category: "special", description: "A sharp blade of air." },
  { name: "Hurricane", type: "Flying", power: 110, category: "special", description: "A devastating hurricane." },

  // Psychic
  { name: "Confusion", type: "Psychic", power: 50, category: "special", description: "A weak telekinetic attack." },
  { name: "Psybeam", type: "Psychic", power: 65, category: "special", description: "A psychic beam." },
  { name: "Psychic", type: "Psychic", power: 90, category: "special", description: "A powerful psychic blast." },
  { name: "Future Sight", type: "Psychic", power: 120, category: "special", description: "A delayed psychic attack." },

  // Bug
  { name: "Bug Bite", type: "Bug", power: 60, category: "physical", description: "A sharp bug bite." },
  { name: "X-Scissor", type: "Bug", power: 80, category: "physical", description: "Crossing scythe attack." },
  { name: "Bug Buzz", type: "Bug", power: 90, category: "special", description: "A destructive vibration." },
  { name: "Megahorn", type: "Bug", power: 120, category: "physical", description: "A powerful horn attack." },

  // Rock
  { name: "Rock Throw", type: "Rock", power: 50, category: "physical", description: "A thrown rock." },
  { name: "Rock Slide", type: "Rock", power: 75, category: "physical", description: "A barrage of rocks." },
  { name: "Power Gem", type: "Rock", power: 80, category: "special", description: "A ray of gem light." },
  { name: "Stone Edge", type: "Rock", power: 100, category: "physical", description: "Stones with sharp edges." },

  // Ghost
  { name: "Lick", type: "Ghost", power: 30, category: "physical", description: "A ghostly lick." },
  { name: "Shadow Claw", type: "Ghost", power: 70, category: "physical", description: "A ghostly slash." },
  { name: "Shadow Ball", type: "Ghost", power: 80, category: "special", description: "A ghostly energy ball." },
  { name: "Phantom Force", type: "Ghost", power: 90, category: "physical", description: "An otherworldly attack." },

  // Dragon
  { name: "Dragon Rage", type: "Dragon", power: 60, category: "special", description: "A shock of dragon energy." },
  { name: "Dragon Claw", type: "Dragon", power: 80, category: "physical", description: "Sharp dragon claws." },
  { name: "Dragon Pulse", type: "Dragon", power: 85, category: "special", description: "A wave of dragon power." },
  { name: "Outrage", type: "Dragon", power: 120, category: "physical", description: "A rampaging dragon attack." },

  // Dark
  { name: "Bite", type: "Dark", power: 60, category: "physical", description: "A sharp bite." },
  { name: "Night Slash", type: "Dark", power: 70, category: "physical", description: "A dark slash attack." },
  { name: "Dark Pulse", type: "Dark", power: 80, category: "special", description: "A wave of dark thoughts." },
  { name: "Crunch", type: "Dark", power: 80, category: "physical", description: "A powerful crunch." },

  // Steel
  { name: "Metal Claw", type: "Steel", power: 50, category: "physical", description: "A steel claw attack." },
  { name: "Flash Cannon", type: "Steel", power: 80, category: "special", description: "A flash of steel light." },
  { name: "Iron Tail", type: "Steel", power: 100, category: "physical", description: "A heavy iron tail slam." },
  { name: "Meteor Mash", type: "Steel", power: 90, category: "physical", description: "A meteor-like punch." },

  // Fairy
  { name: "Fairy Wind", type: "Fairy", power: 40, category: "special", description: "A breeze of fairy power." },
  { name: "Dazzling Gleam", type: "Fairy", power: 80, category: "special", description: "A brilliant flash of light." },
  { name: "Play Rough", type: "Fairy", power: 90, category: "physical", description: "A playful but rough attack." },
  { name: "Moonblast", type: "Fairy", power: 95, category: "special", description: "Borrowing lunar power." },
];

export function getMovesForPokemon(types: string[]): Move[] {
  const moves: Move[] = [];
  const usedNames = new Set<string>();

  const addMove = (template: MoveTemplate) => {
    if (!usedNames.has(template.name) && moves.length < 4) {
      moves.push({
        name: template.name,
        type: template.type,
        power: template.power,
        category: template.category,
        description: template.description,
      });
      usedNames.add(template.name);
    }
  };

  // For each type, add a strong and a medium move
  for (const type of types) {
    const typeMoves = MOVE_POOL.filter(m => m.type === type).sort((a, b) => b.power - a.power);
    // Add strongest
    if (typeMoves[0]) addMove(typeMoves[0]);
    // Add medium
    if (typeMoves[1]) addMove(typeMoves[1]);
  }

  // Fill remaining slots with Normal moves
  if (moves.length < 4) {
    const normalMoves = MOVE_POOL.filter(m => m.type === "Normal").sort((a, b) => b.power - a.power);
    for (const m of normalMoves) {
      if (moves.length >= 4) break;
      addMove(m);
    }
  }

  // Fill remaining with any moves
  if (moves.length < 4) {
    for (const m of MOVE_POOL) {
      if (moves.length >= 4) break;
      addMove(m);
    }
  }

  return moves.slice(0, 4);
}

// ============================================================
// DAMAGE CALCULATION
// ============================================================

export function calculateDamage(
  attacker: { pokemon: Pokemon; moves: Move[] },
  defender: { pokemon: Pokemon },
  move: Move
): { damage: number; effectiveness: number; isStab: boolean } {
  const atkStat = move.category === "physical"
    ? attacker.pokemon.stats.attack
    : attacker.pokemon.stats.spAtk;
  const defStat = move.category === "physical"
    ? defender.pokemon.stats.defense
    : defender.pokemon.stats.spDef;

  const effectiveness = getTypeMultiplier(move.type, defender.pokemon.types);
  const isStab = attacker.pokemon.types.includes(move.type);
  const stabMultiplier = isStab ? 1.5 : 1;
  const randomFactor = 0.85 + Math.random() * 0.15;

  // Simplified damage formula tuned for base stats
  const atkRatio = atkStat / Math.max(defStat, 1);
  const baseDamage = move.power * Math.min(atkRatio, 3) * 0.2 + 1;
  const damage = Math.max(1, Math.floor(baseDamage * stabMultiplier * effectiveness * randomFactor));

  return { damage, effectiveness, isStab };
}

export const TYPE_COLORS: Record<string, string> = {
  Normal: "#A8A878",
  Fire: "#F08030",
  Water: "#6890F0",
  Electric: "#F8D030",
  Grass: "#78C850",
  Ice: "#98D8D8",
  Fighting: "#C03028",
  Poison: "#A040A0",
  Ground: "#E0C068",
  Flying: "#A890F0",
  Psychic: "#F85888",
  Bug: "#A8B820",
  Rock: "#B8A038",
  Ghost: "#705898",
  Dragon: "#7038F8",
  Dark: "#705848",
  Steel: "#B8B8D0",
  Fairy: "#EE99AC",
};
