import { Pokemon, PokemonBox, BoxSlot, BoxTheme, ThemeConfig } from "../types";

const p = (
  id: number,
  name: string,
  types: string[],
  hp: number,
  atk: number,
  def: number,
  spa: number,
  spd: number,
  spe: number
): Pokemon => ({
  id,
  name,
  types,
  stats: { hp, attack: atk, defense: def, spAtk: spa, spDef: spd, speed: spe },
  sprite: `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${id}.png`,
});

export const POKEMON_DATA: Pokemon[] = [
  p(1, "Bulbasaur", ["Grass", "Poison"], 45, 49, 49, 65, 65, 45),
  p(2, "Ivysaur", ["Grass", "Poison"], 60, 62, 63, 80, 80, 60),
  p(3, "Venusaur", ["Grass", "Poison"], 80, 82, 83, 100, 100, 80),
  p(4, "Charmander", ["Fire"], 39, 52, 43, 60, 50, 65),
  p(5, "Charmeleon", ["Fire"], 58, 64, 58, 80, 65, 80),
  p(6, "Charizard", ["Fire", "Flying"], 78, 84, 78, 109, 85, 100),
  p(7, "Squirtle", ["Water"], 44, 48, 65, 50, 64, 43),
  p(8, "Wartortle", ["Water"], 59, 63, 80, 65, 80, 58),
  p(9, "Blastoise", ["Water"], 79, 83, 100, 85, 105, 78),
  p(25, "Pikachu", ["Electric"], 35, 55, 40, 50, 50, 90),
  p(26, "Raichu", ["Electric"], 60, 90, 55, 90, 80, 110),
  p(37, "Vulpix", ["Fire"], 38, 41, 40, 50, 65, 65),
  p(38, "Ninetales", ["Fire"], 73, 76, 75, 81, 100, 100),
  p(39, "Jigglypuff", ["Normal", "Fairy"], 115, 45, 20, 45, 25, 20),
  p(52, "Meowth", ["Normal"], 40, 45, 35, 40, 40, 90),
  p(54, "Psyduck", ["Water"], 50, 52, 48, 65, 50, 55),
  p(58, "Growlithe", ["Fire"], 55, 70, 45, 70, 50, 60),
  p(59, "Arcanine", ["Fire"], 90, 110, 80, 100, 80, 95),
  p(60, "Poliwag", ["Water"], 40, 50, 40, 40, 40, 90),
  p(63, "Abra", ["Psychic"], 25, 20, 15, 105, 55, 90),
  p(64, "Kadabra", ["Psychic"], 40, 35, 30, 120, 70, 105),
  p(65, "Alakazam", ["Psychic"], 55, 50, 45, 135, 95, 120),
  p(66, "Machop", ["Fighting"], 70, 80, 50, 35, 35, 35),
  p(67, "Machoke", ["Fighting"], 80, 100, 70, 50, 60, 45),
  p(68, "Machamp", ["Fighting"], 90, 130, 80, 65, 85, 55),
  p(74, "Geodude", ["Rock", "Ground"], 40, 80, 100, 30, 30, 20),
  p(75, "Graveler", ["Rock", "Ground"], 55, 95, 115, 45, 45, 35),
  p(76, "Golem", ["Rock", "Ground"], 80, 120, 130, 55, 65, 45),
  p(77, "Ponyta", ["Fire"], 50, 85, 55, 65, 65, 90),
  p(78, "Rapidash", ["Fire"], 65, 100, 70, 80, 80, 105),
  p(79, "Slowpoke", ["Water", "Psychic"], 90, 65, 65, 40, 40, 15),
  p(80, "Slowbro", ["Water", "Psychic"], 95, 75, 110, 100, 80, 30),
  p(92, "Gastly", ["Ghost", "Poison"], 30, 35, 30, 100, 35, 80),
  p(93, "Haunter", ["Ghost", "Poison"], 45, 50, 45, 115, 55, 95),
  p(94, "Gengar", ["Ghost", "Poison"], 60, 65, 60, 130, 75, 110),
  p(104, "Cubone", ["Ground"], 50, 50, 95, 40, 50, 35),
  p(105, "Marowak", ["Ground"], 60, 80, 110, 50, 80, 45),
  p(106, "Hitmonlee", ["Fighting"], 50, 120, 53, 35, 110, 87),
  p(107, "Hitmonchan", ["Fighting"], 50, 105, 79, 35, 110, 76),
  p(123, "Scyther", ["Bug", "Flying"], 70, 110, 80, 55, 80, 105),
  p(127, "Pinsir", ["Bug"], 65, 125, 100, 55, 70, 85),
  p(128, "Tauros", ["Normal"], 75, 100, 95, 40, 70, 110),
  p(129, "Magikarp", ["Water"], 20, 10, 55, 15, 20, 80),
  p(130, "Gyarados", ["Water", "Flying"], 95, 125, 79, 60, 100, 81),
  p(131, "Lapras", ["Water", "Ice"], 130, 85, 80, 85, 95, 60),
  p(133, "Eevee", ["Normal"], 55, 55, 50, 45, 65, 55),
  p(137, "Porygon", ["Normal"], 65, 60, 70, 85, 75, 40),
  p(142, "Aerodactyl", ["Rock", "Flying"], 80, 105, 65, 60, 75, 130),
  p(143, "Snorlax", ["Normal"], 160, 110, 65, 65, 110, 30),
  p(144, "Articuno", ["Ice", "Flying"], 90, 85, 100, 95, 125, 85),
  p(145, "Zapdos", ["Electric", "Flying"], 90, 90, 85, 125, 90, 100),
  p(146, "Moltres", ["Fire", "Flying"], 90, 100, 90, 125, 85, 90),
  p(147, "Dratini", ["Dragon"], 41, 64, 45, 50, 50, 50),
  p(148, "Dragonair", ["Dragon"], 61, 84, 65, 70, 70, 70),
  p(149, "Dragonite", ["Dragon", "Flying"], 91, 134, 95, 100, 100, 80),
  p(150, "Mewtwo", ["Psychic"], 106, 110, 90, 154, 90, 130),
  p(151, "Mew", ["Psychic"], 100, 100, 100, 100, 100, 100),
];

export const TYPE_COLORS: Record<string, { bg: string; text: string }> = {
  Normal: { bg: "#A8A878", text: "#ffffff" },
  Fire: { bg: "#F08030", text: "#ffffff" },
  Water: { bg: "#6890F0", text: "#ffffff" },
  Electric: { bg: "#F8D030", text: "#333333" },
  Grass: { bg: "#78C850", text: "#ffffff" },
  Ice: { bg: "#98D8D8", text: "#333333" },
  Fighting: { bg: "#C03028", text: "#ffffff" },
  Poison: { bg: "#A040A0", text: "#ffffff" },
  Ground: { bg: "#E0C068", text: "#333333" },
  Flying: { bg: "#A890F0", text: "#ffffff" },
  Psychic: { bg: "#F85888", text: "#ffffff" },
  Bug: { bg: "#A8B820", text: "#ffffff" },
  Rock: { bg: "#B8A038", text: "#ffffff" },
  Ghost: { bg: "#705898", text: "#ffffff" },
  Dragon: { bg: "#7038F8", text: "#ffffff" },
  Dark: { bg: "#705848", text: "#ffffff" },
  Steel: { bg: "#B8B8D0", text: "#333333" },
  Fairy: { bg: "#EE99AC", text: "#333333" },
};

export const ALL_TYPES = Object.keys(TYPE_COLORS);

export const THEME_CONFIGS: Record<BoxTheme, ThemeConfig> = {
  classic: {
    label: "Classic",
    emoji: "🎮",
    gradient: "linear-gradient(135deg, #4a6cf7 0%, #6b8cff 40%, #8ba4ff 100%)",
    slotBg: "rgba(255,255,255,0.12)",
    slotBorder: "rgba(255,255,255,0.2)",
    headerBg: "rgba(0,0,0,0.3)",
    textColor: "#ffffff",
    accent: "#6b8cff",
  },
  forest: {
    label: "Forest",
    emoji: "🌿",
    gradient: "linear-gradient(135deg, #134e5e 0%, #1b7a3d 50%, #2ecc71 100%)",
    slotBg: "rgba(255,255,255,0.1)",
    slotBorder: "rgba(46,204,113,0.3)",
    headerBg: "rgba(0,0,0,0.35)",
    textColor: "#d4edda",
    accent: "#2ecc71",
  },
  ocean: {
    label: "Ocean",
    emoji: "🌊",
    gradient: "linear-gradient(135deg, #0c2461 0%, #1e3799 40%, #3c6382 100%)",
    slotBg: "rgba(255,255,255,0.08)",
    slotBorder: "rgba(96,165,250,0.3)",
    headerBg: "rgba(0,0,0,0.4)",
    textColor: "#bfdbfe",
    accent: "#60a5fa",
  },
  volcano: {
    label: "Volcano",
    emoji: "🌋",
    gradient: "linear-gradient(135deg, #6b0f1a 0%, #b71c1c 40%, #e65100 100%)",
    slotBg: "rgba(255,255,255,0.1)",
    slotBorder: "rgba(255,167,38,0.3)",
    headerBg: "rgba(0,0,0,0.35)",
    textColor: "#ffe0b2",
    accent: "#ff6d00",
  },
  electric: {
    label: "Electric",
    emoji: "⚡",
    gradient: "linear-gradient(135deg, #6d4c00 0%, #c79c00 40%, #ffd600 100%)",
    slotBg: "rgba(0,0,0,0.1)",
    slotBorder: "rgba(255,214,0,0.4)",
    headerBg: "rgba(0,0,0,0.3)",
    textColor: "#1a1a1a",
    accent: "#fdd835",
  },
  night: {
    label: "Night",
    emoji: "🌙",
    gradient: "linear-gradient(135deg, #0d0221 0%, #1a0533 40%, #3c1361 100%)",
    slotBg: "rgba(255,255,255,0.06)",
    slotBorder: "rgba(156,39,176,0.3)",
    headerBg: "rgba(0,0,0,0.5)",
    textColor: "#e1bee7",
    accent: "#ab47bc",
  },
  psychic: {
    label: "Psychic",
    emoji: "🔮",
    gradient: "linear-gradient(135deg, #880e4f 0%, #c2185b 40%, #f48fb1 100%)",
    slotBg: "rgba(255,255,255,0.12)",
    slotBorder: "rgba(244,143,177,0.3)",
    headerBg: "rgba(0,0,0,0.3)",
    textColor: "#fce4ec",
    accent: "#f06292",
  },
  cave: {
    label: "Cave",
    emoji: "🏔️",
    gradient: "linear-gradient(135deg, #1a1a2e 0%, #34344a 40%, #4a4a68 100%)",
    slotBg: "rgba(255,255,255,0.08)",
    slotBorder: "rgba(120,120,150,0.3)",
    headerBg: "rgba(0,0,0,0.4)",
    textColor: "#c5cae9",
    accent: "#7986cb",
  },
};

export const ALL_THEMES: BoxTheme[] = [
  "classic",
  "forest",
  "ocean",
  "volcano",
  "electric",
  "night",
  "psychic",
  "cave",
];

const SLOTS_PER_BOX = 30;
const COLS = 5;
const ROWS = 6;

export const createInitialBoxes = (): PokemonBox[] => {
  const boxConfigs: { name: string; theme: BoxTheme }[] = [
    { name: "Starter Box", theme: "classic" },
    { name: "Battle Team", theme: "ocean" },
    { name: "Legendaries", theme: "night" },
    { name: "Empty Box", theme: "forest" },
    { name: "Empty Box", theme: "volcano" },
    { name: "Empty Box", theme: "electric" },
  ];

  return boxConfigs.map((config, i) => {
    const start = i * SLOTS_PER_BOX;
    const end = start + SLOTS_PER_BOX;
    const boxPokemon = POKEMON_DATA.slice(start, end);

    const slots: BoxSlot[] = Array.from({ length: SLOTS_PER_BOX }, (_, j) => ({
      pokemon: boxPokemon[j] || null,
    }));

    return {
      id: i + 1,
      name: config.name,
      theme: config.theme,
      slots,
    };
  });
};

export { SLOTS_PER_BOX, COLS, ROWS };
