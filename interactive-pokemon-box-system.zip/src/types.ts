export interface PokemonStats {
  hp: number;
  attack: number;
  defense: number;
  spAtk: number;
  spDef: number;
  speed: number;
}

export interface Pokemon {
  id: number;
  name: string;
  types: string[];
  stats: PokemonStats;
  sprite: string;
}

export interface BoxSlot {
  pokemon: Pokemon | null;
}

export interface PokemonBox {
  id: number;
  name: string;
  theme: BoxTheme;
  slots: BoxSlot[];
}

export type BoxTheme =
  | "classic"
  | "forest"
  | "ocean"
  | "volcano"
  | "electric"
  | "night"
  | "psychic"
  | "cave";

export interface ThemeConfig {
  label: string;
  emoji: string;
  gradient: string;
  slotBg: string;
  slotBorder: string;
  headerBg: string;
  textColor: string;
  accent: string;
}

export interface DragInfo {
  boxIdx: number;
  slotIdx: number;
}

// ---- Battle Types ----

export interface Move {
  name: string;
  type: string;
  power: number;
  category: "physical" | "special";
  description: string;
}

export interface BattlePokemon {
  pokemon: Pokemon;
  currentHp: number;
  maxHp: number;
  moves: Move[];
  statModifiers: {
    attack: number;
    defense: number;
    spAtk: number;
    spDef: number;
    speed: number;
  };
}

export type BattlePhase =
  | "select"
  | "intro"
  | "playerTurn"
  | "attacking"
  | "enemyTurn"
  | "enemyAttacking"
  | "result";

export interface BattleLogEntry {
  message: string;
  type: "info" | "damage" | "effective" | "miss" | "faint" | "turn";
}

export type AppView = "boxes" | "battle" | "multiplayer";
