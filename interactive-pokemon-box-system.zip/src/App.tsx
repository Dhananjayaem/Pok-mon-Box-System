import { useState, useCallback } from "react";
import { PokemonBox, DragInfo, BoxTheme, AppView } from "./types";
import {
  createInitialBoxes,
  THEME_CONFIGS,
  ALL_THEMES,
  ALL_TYPES,
  TYPE_COLORS,
} from "./data/pokemon";
import BoxGrid from "./components/BoxGrid";
import BattleArena from "./components/BattleArena";
import MultiplayerLobby from "./components/MultiplayerLobby";

export default function App() {
  const [boxes, setBoxes] = useState<PokemonBox[]>(createInitialBoxes);
  const [activeBox, setActiveBox] = useState(0);
  const [dragSource, setDragSource] = useState<DragInfo | null>(null);
  const [dragOver, setDragOver] = useState<DragInfo | null>(null);
  const [searchType, setSearchType] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [editingBoxName, setEditingBoxName] = useState<number | null>(null);
  const [boxNameInput, setBoxNameInput] = useState("");
  const [showThemePanel, setShowThemePanel] = useState(false);
  const [appView, setAppView] = useState<AppView>("boxes");

  // --- Drag & Drop Handlers ---
  const handleDragStart = useCallback(
    (_e: React.DragEvent, boxIdx: number, slotIdx: number) => {
      setDragSource({ boxIdx, slotIdx });
    },
    []
  );

  const handleDragEnd = useCallback(() => {
    setDragSource(null);
    setDragOver(null);
  }, []);

  const handleDrop = useCallback(
    (_e: React.DragEvent, boxIdx: number, slotIdx: number) => {
      if (!dragSource) return;
      if (dragSource.boxIdx === boxIdx && dragSource.slotIdx === slotIdx) {
        setDragSource(null);
        setDragOver(null);
        return;
      }

      setBoxes((prev) => {
        const newBoxes = prev.map((box) => ({ ...box, slots: [...box.slots] }));
        const srcPokemon =
          newBoxes[dragSource.boxIdx].slots[dragSource.slotIdx].pokemon;
        const dstPokemon =
          newBoxes[boxIdx].slots[slotIdx].pokemon;
        newBoxes[dragSource.boxIdx].slots[dragSource.slotIdx] = {
          pokemon: dstPokemon,
        };
        newBoxes[boxIdx].slots[slotIdx] = { pokemon: srcPokemon };
        return newBoxes;
      });

      setDragSource(null);
      setDragOver(null);
    },
    [dragSource]
  );

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
  }, []);

  const handleDragEnter = useCallback(
    (boxIdx: number, slotIdx: number) => {
      setDragOver({ boxIdx, slotIdx });
    },
    []
  );

  const handleDragLeave = useCallback(() => {}, []);

  // --- Theme Change ---
  const handleThemeChange = useCallback(
    (theme: BoxTheme) => {
      setBoxes((prev) => {
        const newBoxes = [...prev];
        newBoxes[activeBox] = { ...newBoxes[activeBox], theme };
        return newBoxes;
      });
      setShowThemePanel(false);
    },
    [activeBox]
  );

  // --- Box Name Editing ---
  const startEditing = (boxIdx: number, currentName: string) => {
    setEditingBoxName(boxIdx);
    setBoxNameInput(currentName);
  };

  const saveBoxName = (boxIdx: number) => {
    if (boxNameInput.trim()) {
      setBoxes((prev) => {
        const newBoxes = [...prev];
        newBoxes[boxIdx] = {
          ...newBoxes[boxIdx],
          name: boxNameInput.trim(),
        };
        return newBoxes;
      });
    }
    setEditingBoxName(null);
    setBoxNameInput("");
  };

  // --- Derived State ---
  const currentBox = boxes[activeBox];
  const themeConfig = THEME_CONFIGS[currentBox.theme];
  const pokemonCount = currentBox.slots.filter((s) => s.pokemon).length;
  const totalPokemon = boxes.reduce(
    (acc, box) => acc + box.slots.filter((s) => s.pokemon).length,
    0
  );
  const isFiltered = searchType !== null || searchTerm.length > 0;

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      {/* ===== HEADER ===== */}
      <header className="relative overflow-hidden bg-gradient-to-r from-red-700 via-red-600 to-red-700 shadow-lg">
        {/* Decorative circles */}
        <div className="absolute -top-10 -right-10 w-40 h-40 rounded-full border-4 border-white/10" />
        <div className="absolute top-2 right-6 w-20 h-20 rounded-full bg-white/5" />

        <div className="relative max-w-5xl mx-auto px-4 py-4 flex items-center justify-between">
          {/* Left: Logo + title */}
          <div className="flex items-center gap-3">
            {/* Pokeball icon */}
            <div className="w-11 h-11 rounded-full bg-white/15 backdrop-blur-sm flex items-center justify-center border border-white/20 shadow-inner">
              <svg viewBox="0 0 100 100" className="w-7 h-7" fill="none">
                <circle cx="50" cy="50" r="48" stroke="white" strokeWidth="5" opacity="0.8" />
                <line x1="2" y1="50" x2="98" y2="50" stroke="white" strokeWidth="5" opacity="0.8" />
                <circle cx="50" cy="50" r="14" stroke="white" strokeWidth="5" opacity="0.8" />
                <circle cx="50" cy="50" r="6" fill="white" opacity="0.6" />
              </svg>
            </div>
            <div>
              <h1 className="text-xl font-extrabold tracking-tight text-white drop-shadow">
                Pokémon Box System
              </h1>
              <p className="text-[11px] text-red-100/70 font-medium">
                {totalPokemon} Pokémon stored · {boxes.length} Boxes
              </p>
            </div>
          </div>

          {/* Right: Nav buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setAppView("boxes")}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold transition-all
                         ${
                           appView === "boxes"
                             ? "bg-white/20 text-white shadow-inner"
                             : "bg-white/10 text-white/70 hover:bg-white/15 hover:text-white"
                         }`}
            >
              <span>📦</span>
              <span className="hidden sm:inline">Boxes</span>
            </button>
            <button
              onClick={() => setAppView("battle")}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold transition-all
                         ${
                           appView === "battle"
                             ? "bg-white/20 text-white shadow-inner"
                             : "bg-white/10 text-white/70 hover:bg-white/15 hover:text-white"
                         }`}
            >
              <span>⚔️</span>
              <span className="hidden sm:inline">Battle</span>
            </button>
            <button
              onClick={() => setAppView("multiplayer")}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold transition-all
                         ${
                           appView === "multiplayer"
                             ? "bg-white/20 text-white shadow-inner"
                             : "bg-white/10 text-white/70 hover:bg-white/15 hover:text-white"
                         }`}
            >
              <span>🌐</span>
              <span className="hidden sm:inline">Online</span>
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-3 sm:px-4 py-4">
        {/* ===== BATTLE MODE ===== */}
        {appView === "battle" && (
          <BattleArena boxes={boxes} onBack={() => setAppView("boxes")} />
        )}

        {/* ===== MULTIPLAYER MODE ===== */}
        {appView === "multiplayer" && (
          <MultiplayerLobby boxes={boxes} onBack={() => setAppView("boxes")} />
        )}

        {/* ===== BOXES MODE ===== */}
        {appView === "boxes" && (
          <div className="space-y-3">
            {/* Search & Type Filter */}
            <div className="bg-slate-900/70 rounded-xl border border-slate-800/80 p-3 space-y-2.5">
              {/* Search input row */}
              <div className="flex items-center gap-2">
                <svg
                  className="w-4 h-4 text-slate-500 shrink-0"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                  />
                </svg>
                <input
                  type="text"
                  placeholder="Search by Pokémon name..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="flex-1 bg-slate-800/80 border border-slate-700/60 rounded-lg px-3 py-1.5 text-sm
                             focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-transparent
                             placeholder-slate-500 text-white"
                />
                {(searchTerm || searchType) && (
                  <button
                    onClick={() => {
                      setSearchTerm("");
                      setSearchType(null);
                    }}
                    className="px-2.5 py-1.5 bg-slate-700/80 hover:bg-slate-600 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap"
                  >
                    ✕ Clear
                  </button>
                )}
              </div>

              {/* Type filter pills */}
              <div className="flex items-center gap-1 flex-wrap">
                <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider mr-0.5">
                  Type
                </span>
                <button
                  onClick={() => setSearchType(null)}
                  className={`px-2 py-[3px] rounded text-[10px] font-bold uppercase tracking-wide transition-all border
                             ${
                               !searchType
                                 ? "bg-white/15 border-white/30 text-white"
                                 : "bg-slate-800/60 border-slate-700/40 text-slate-400 hover:text-slate-200"
                             }`}
                >
                  All
                </button>
                {ALL_TYPES.map((type) => {
                  const colors = TYPE_COLORS[type];
                  const isActive = searchType === type;
                  return (
                    <button
                      key={type}
                      onClick={() => setSearchType(isActive ? null : type)}
                      className={`px-2 py-[3px] rounded text-[10px] font-bold uppercase tracking-wide transition-all
                                 ${
                                   isActive
                                     ? "ring-2 ring-white/50 scale-110 shadow-lg"
                                     : "opacity-50 hover:opacity-90 hover:scale-105"
                                 }`}
                      style={{
                        backgroundColor: colors.bg,
                        color: colors.text,
                      }}
                    >
                      {type}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Tabs + Theme Toggle */}
            <div className="flex items-start justify-between gap-2">
              {/* Box tabs */}
              <div className="flex items-center gap-1 overflow-x-auto pb-1 flex-1 scrollbar-thin">
                {boxes.map((box, i) => {
                  const count = box.slots.filter((s) => s.pokemon).length;
                  const isActive = i === activeBox;
                  const tabTheme = THEME_CONFIGS[box.theme];
                  return (
                    <button
                      key={box.id}
                      onClick={() => setActiveBox(i)}
                      className={`relative flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold transition-all whitespace-nowrap shrink-0
                                 ${
                                   isActive
                                     ? "text-white shadow-lg"
                                     : "bg-slate-800/50 text-slate-400 hover:text-slate-200 hover:bg-slate-800"
                                 }`}
                      style={
                        isActive
                          ? {
                              background: tabTheme.gradient,
                              boxShadow: `0 4px 15px ${tabTheme.accent}30`,
                            }
                          : undefined
                      }
                    >
                      <span className="text-sm">{tabTheme.emoji}</span>
                      {editingBoxName === i ? (
                        <input
                          type="text"
                          value={boxNameInput}
                          onChange={(e) => setBoxNameInput(e.target.value)}
                          onBlur={() => saveBoxName(i)}
                          onKeyDown={(e) => {
                            if (e.key === "Enter") saveBoxName(i);
                            if (e.key === "Escape") {
                              setEditingBoxName(null);
                              setBoxNameInput("");
                            }
                          }}
                          className="bg-black/30 rounded px-1.5 py-0.5 w-24 text-[11px] text-white focus:outline-none focus:ring-1 focus:ring-white/40"
                          autoFocus
                          onClick={(e) => e.stopPropagation()}
                        />
                      ) : (
                        <span
                          onDoubleClick={(e) => {
                            e.stopPropagation();
                            startEditing(i, box.name);
                          }}
                          title="Double-click to rename"
                          className="max-w-[80px] truncate"
                        >
                          {box.name}
                        </span>
                      )}
                      <span
                        className={`text-[10px] font-mono ${
                          isActive ? "text-white/50" : "text-slate-600"
                        }`}
                      >
                        {count}
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* Theme toggle button */}
              <div className="relative">
                <button
                  onClick={() => setShowThemePanel(!showThemePanel)}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-800/60 border border-slate-700/50
                             hover:bg-slate-700/60 transition-colors text-xs font-semibold text-slate-300 shrink-0"
                >
                  <span>🎨</span>
                  <span className="hidden sm:inline">Theme</span>
                </button>

                {/* Theme dropdown */}
                {showThemePanel && (
                  <>
                    <div
                      className="fixed inset-0 z-30"
                      onClick={() => setShowThemePanel(false)}
                    />
                    <div className="absolute right-0 top-full mt-2 z-40 bg-slate-900 border border-slate-700/80 rounded-xl p-2 shadow-2xl w-52">
                      <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider px-2 mb-1.5">
                        Box Theme
                      </p>
                      <div className="grid grid-cols-2 gap-1">
                        {ALL_THEMES.map((theme) => {
                          const config = THEME_CONFIGS[theme];
                          const isActive = currentBox.theme === theme;
                          return (
                            <button
                              key={theme}
                              onClick={() => handleThemeChange(theme)}
                              className={`flex items-center gap-2 px-2 py-2 rounded-lg text-left transition-all
                                         ${
                                           isActive
                                             ? "ring-2 ring-white/40 shadow-lg"
                                             : "hover:bg-white/5"
                                         }`}
                              style={{
                                background: isActive ? config.gradient : undefined,
                              }}
                            >
                              <div
                                className="w-6 h-6 rounded-full shrink-0 border border-white/20"
                                style={{ background: config.gradient }}
                              />
                              <div className="min-w-0">
                                <div
                                  className="text-[11px] font-semibold truncate"
                                  style={{
                                    color: isActive ? config.textColor : "#e2e8f0",
                                  }}
                                >
                                  {config.emoji} {config.label}
                                </div>
                              </div>
                              {isActive && <span className="ml-auto text-xs">✓</span>}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </>
                )}
              </div>
            </div>

            {/* Box Grid */}
            <BoxGrid
              box={currentBox}
              boxIdx={activeBox}
              themeConfig={themeConfig}
              dragSource={dragSource}
              dragOver={dragOver}
              searchType={searchType}
              searchTerm={searchTerm}
              onDragStart={handleDragStart}
              onDragEnd={handleDragEnd}
              onDrop={handleDrop}
              onDragOver={handleDragOver}
              onDragEnter={handleDragEnter}
              onDragLeave={handleDragLeave}
            />

            {/* Footer Status */}
            <div
              className="flex items-center justify-between rounded-xl px-4 py-2.5 border border-white/10 transition-all duration-300"
              style={{
                background: themeConfig.gradient,
                opacity: 0.8,
              }}
            >
              <div className="flex items-center gap-3">
                <span
                  className="text-sm font-bold"
                  style={{ color: themeConfig.textColor }}
                >
                  {themeConfig.emoji} {currentBox.name}
                </span>
                <span
                  className="text-xs font-mono"
                  style={{ color: themeConfig.textColor, opacity: 0.5 }}
                >
                  {pokemonCount}/30 Pokémon
                </span>
                {isFiltered && (
                  <span
                    className="text-[10px] px-2 py-0.5 rounded-full bg-white/10 font-semibold"
                    style={{ color: themeConfig.textColor }}
                  >
                    Filtered
                  </span>
                )}
              </div>
              <div className="flex items-center gap-2">
                <span
                  className="text-[10px] uppercase tracking-wider font-semibold opacity-50"
                  style={{ color: themeConfig.textColor }}
                >
                  {themeConfig.label}
                </span>
                <div
                  className="w-3 h-3 rounded-full border border-white/20"
                  style={{ background: themeConfig.accent }}
                />
              </div>
            </div>

            {/* Help text */}
            <p className="text-center text-[10px] text-slate-700 leading-relaxed">
              Drag Pokémon between slots to rearrange · Hover over Pokémon for stat
              details · Double-click tab names to rename · Change box themes with
              the 🎨 button · Click ⚔️ Battle to fight!
            </p>
          </div>
        )}
      </main>
    </div>
  );
}
